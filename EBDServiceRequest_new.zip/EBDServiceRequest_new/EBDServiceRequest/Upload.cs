﻿using System;
using System.Web;

namespace EBDServiceRequest
{
    public class Upload : IHttpHandler
    {
        /// <summary>
        /// You will need to configure this handler in the Web.config file of your 
        /// web and register it with IIS before being able to use it. For more information
        /// see the following link: http://go.microsoft.com/?linkid=8101007
        /// </summary>
        #region IHttpHandler Members

        public bool IsReusable
        {
            // Return false in case your Managed Handler cannot be reused for another request.
            // Usually this would be false in case you have some state information preserved per request.
            get { return true; }
        }

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            context.Response.Expires = -1;
            try
            {
                HttpFileCollection hfc = context.Request.Files;
                for (int i = 0; i <= hfc.Count - 1; i++)
                {
                    HttpPostedFile hpf = hfc[i];
                    if (hpf.ContentLength > 0)
                    {
                        //filename = hpf.FileName;
                        //string folderName = string.Empty;
                        //if (Session["SectionID"].ToString().Equals("4"))
                        //{
                        //    folderName = newfolderNme;                       //  ConfigurationManager.AppSettings["SurveyfolderName"].ToString();
                        //    filePath = Path.Combine(folderName, filename);
                        //}
                        //else
                        //{
                        //    folderName = ConfigurationManager.AppSettings["NonEBDfolderName"].ToString();
                        //    filePath = Path.Combine(folderName, filename);
                        //}
                        //string filePath = @"\\MV2GISS01\Survey\" + hpf.FileName;
                        //hpf.SaveAs(filePath);

                        hpf.SaveAs(@"\\MV2GISS01\Survey\" + hpf.FileName.Substring(hpf.FileName.LastIndexOf('\\') + 1).Replace(hpf.FileName.Substring(hpf.FileName.LastIndexOf('\\') + 1).Split('.')[0],
                            "SamplePolygon"));
                    }
                }
            }
            catch (Exception ex)
            {
                context.Response.Write("Error occurred while uploading the file");
            }
        }

        #endregion
    }
}
