﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EBDServiceRequest.Models
{
    public partial class ViewSurveyRequest
    {
        public string EmailID { set; get; }
        public string Project_No { set; get; }

        public string Project_Name { set; get; }
        public string Description { set; get; }
        public string WorkQty { set; get; }
        public string RefNo { set; get; }
        public string Priority { set; get; }
        public string Request_Time { set; get; }
        public string Expected_Comp_Date { set; get; }         
        public string Purpose {set; get; }
        public string Status {set; get; }
        public string ContractorName { set; get; }
        public string DepartmentName { set; get; }
        public string Request_Id { set; get; }
        //public virtual PagedList.IPagedList<ViewSurveyRequest> Steps { get; set; }
        //Create a list of this class
        //public List<ViewSurveyRequest> vsr { set; get; }
    }
}