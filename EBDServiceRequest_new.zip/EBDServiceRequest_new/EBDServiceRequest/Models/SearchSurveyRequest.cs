﻿using PagedList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EBDServiceRequest.Models
{
    public class SearchSurveyRequest
    {
        //public IPagedList<ViewSurveyRequest> listVSR { get; set; }
        public IPagedList<ViewSurveyRequest> listVSR { get; set; }
        public SearchSurveyRequest()
        {
            listVSR = new List<ViewSurveyRequest>().ToPagedList(1, 10);
        }
    }
}