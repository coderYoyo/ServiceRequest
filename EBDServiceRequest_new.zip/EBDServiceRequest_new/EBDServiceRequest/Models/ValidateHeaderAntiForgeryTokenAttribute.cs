﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;

namespace EBDServiceRequest.Models
{
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, AllowMultiple = false, Inherited = true)]
    public sealed class ValidateHeaderAntiForgeryTokenAttribute : FilterAttribute, IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationContext filterContext)
        {
            if (filterContext == null)
            {
                throw new ArgumentNullException("filterContext");
            }

            //var httpContext = filterContext.HttpContext;
            //var cookie = httpContext.Request.Cookies[AntiForgeryConfig.CookieName];
            //if (httpContext.Request.Headers["__RequestVerificationToken"] != null)
            //{
            //    AntiForgery.Validate(cookie != null ? httpContext.Request.Headers["__RequestVerificationToken"] : null, httpContext.Request.Headers["__RequestVerificationToken"]);
            //}

            var formValue = filterContext.RequestContext.HttpContext.Request.Form["__RequestVerificationToken"];
            var headerValue = filterContext.RequestContext.HttpContext.Request.Headers["__RequestVerificationToken"];
            string cookieValue = null;
            var cookieInstance = filterContext.RequestContext.HttpContext.Request.Cookies["__RequestVerificationToken"];
            if (cookieInstance != null)
            {
            cookieValue = cookieInstance.Value;
            }

            if (formValue == null)
            {
                formValue = headerValue;
            }

            AntiForgery.Validate(cookieValue, formValue);
         }
     }
    
}