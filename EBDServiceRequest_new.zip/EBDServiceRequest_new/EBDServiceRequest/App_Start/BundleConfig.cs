﻿using System.Web;
using System.Web.Optimization;

namespace EBDServiceRequest
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(new string[]
            {      
                "~/Scripts/jquery-1.12.4.min.js",
                "~/Scripts/jquery-ui.js"
	            //"~/Scripts/jquery-1.10.4-ui.js"                
            }));

            bundles.Add(new ScriptBundle("~/bundles/jqueryBootStrap").Include(new string[]
            {      
                "~/Scripts/jquery-1.12.4.min.js",
                "~/Scripts/bootstrap.min.js",
	            "~/Scripts/jquery-1.10.4-ui.js"
            }));

            bundles.Add(new ScriptBundle("~/bundles/jqueryForMap").Include(new string[]
            {      
                //"~/Scripts/jquery-1.12.4.min.js",				                                
                "~/Scripts/init_27.js",
                "~/Scripts/ajaxfileupload.js", 
                //"<script src='https://js.arcgis.com/3.22/' type='text/javascript'></script>"
                                
            }));


            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(new string[]
            {        
                "~/Scripts/jquery-1.12.4.min.js",
                "~/Scripts/modernizr-*"
            }));

            //  "~/Scripts/jquery-1.12.4.min.js","~/Scripts/init.js"          
            //"~/Scripts/Editor.js"               			
            //"~/Scripts/jquery-1.12.4.min.js",
            //"~/Scripts/jsapi_en-us.js",
            //    "~/Scripts/VectorTileLayerImpl.js",
            //bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include("~/Scripts/jquery.validate*", new IItemTransform[0]));
            //bundles.Add(new ScriptBundle("~/bundles/modernizr").Include("~/Scripts/modernizr-*"));
            //bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(new string[]
            //{
            //    "~/Scripts/bootstrap.js",
            //    "~/Scripts/respond.js"
            //}));
             //"~/Scripts/modernizr-*",
             //   "~/Scripts/bootstrap.js",
            bundles.Add(new StyleBundle("~/Content/cssOnLoad").Include(
                     "~/Content/datePickerCss").Include(new string[] { "~/Content/jquery-ui.css", "~/Content/Site.css" })); //, "~/Content/bootstrap.min.css" "~/Content/bootstrap1.min.css",
            bundles.Add(new StyleBundle("~/Content/cssPagedList").Include(
                     "~/Content/PagedList.css")); // "~/Content/bootstrap.min.css",
            bundles.Add(new StyleBundle("~/Content/cssForMap").Include(
                     "~/Content/claro.css", "~/Content/esri.css"));
            //bundles.Add(new StyleBundle("~/Content/datePickerCss").Include(new string[] { "~/Content/jquery-ui.min.css", "~/Content/Site.css"}));

            //bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
            //                      "~/Scripts/modernizr-{version}.js"));
            //bundles.Add(new StyleBundle("~/Content/datePickerCss").Include("~/Content/jquery-ui.min.css","~/Content/jquery-ui.min.js"));
            //bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
            //           "~/Scripts/jquery-{version}.js"));
            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
           

            //bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
            //          "~/Scripts/bootstrap.js",
            //          "~/Scripts/respond.js"));

            

                
             
        }
    }
}
