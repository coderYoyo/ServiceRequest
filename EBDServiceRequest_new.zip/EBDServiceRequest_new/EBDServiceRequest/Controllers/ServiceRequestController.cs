﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using EBDServiceRequest.Models;
using System.Configuration;
using System.IO;
using System.DirectoryServices;
using System.Data.SqlClient;
using PagedList;
using System.Net.Mail;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Data.Entity.SqlServer;
using Oracle.ManagedDataAccess.Client;
using System.Web.Services;
using System.Web.Script.Services;
using System.Globalization;
using System.Collections;
//using Oracle.ManagedDataAccess.Client;


namespace EBDServiceRequest.Controllers
{
    public class ServiceRequestController : Controller
    {
        private eBookUnitTestDBEntities db = new eBookUnitTestDBEntities();
        
        //// GET: /ServiceRequest/ServiceRequest
        public ActionResult ServiceRequest()
        {
            //ViewData["msg"] = "SERVICE AND SURVEY REQUEST";
            if (Request.Cookies["culture"] != null)
            {
                if (Request.Cookies["culture"].Value == "en")
                {
                    ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
                    ViewData["msg"] = "SERVICE REQUEST";
                    ViewData["divCreateSR"] = EBDServiceRequest.Resource.divCreateSR;
                }
                else
                {
                    ViewData["firstHeading"] = EBDServiceRequest.ResourceAr.firstHeading;
                    ViewData["msg"] = "طلب خدمة";
                    ViewData["divCreateSR"] = EBDServiceRequest.ResourceAr.divCreateSR;
                }
            }
            else
            {
                Request.Cookies["culture"].Value = "en";
                ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
                ViewData["msg"] = "SERVICE REQUEST";
                ViewData["divCreateSR"] = EBDServiceRequest.Resource.divCreateSR;
            }
            return View();
        }

        public ActionResult ChangeHomePageLanguage(string lang)
        {
            new ManageLanguage().SetLanguage(lang);
            return RedirectToAction("ServiceRequest", "ServiceRequest");
        }

        public ActionResult ChangeLanguage(string lang)
        {
            new ManageLanguage().SetLanguage(lang);
            return RedirectToAction("CreateSR", "ServiceRequest");
        }

        protected override IAsyncResult BeginExecuteCore(AsyncCallback callback, object state)
        {
            string lang = null;
            HttpCookie langCookie = Request.Cookies["culture"];
            if (langCookie != null)
            {
                lang = langCookie.Value;
            }
            else
            {
                var userLanguage = Request.UserLanguages;
                var userLang = userLanguage != null ? userLanguage[0] : "";
                if (userLang != "")
                {
                    lang = userLang;
                }
                else
                {
                    lang = ManageLanguage.GetDefaultLanguage();
                }
            }
            new ManageLanguage().SetLanguage(lang);
            return base.BeginExecuteCore(callback, state);
        }  

        //// GET: /ServiceRequest/SearchSR
        public ActionResult SearchSR([Bind(Include = "emailID")] EBDServiceRequests ebdservicerequests, int? page, string submit, string lang)
        {
            if (lang != null)
            {
                Request.Cookies["culture"].Value = lang;
                Session["Lang"] = lang;
                //if (lang == "Ar")
                //{
                //    new ManageLanguage().SetLanguage("Arabic");
                     
                //}
                //else if (lang == "en")
                //{
                //    new ManageLanguage().SetLanguage("English");
                //}
            }
            else if (Session["Lang"]!=null)
            {
                Request.Cookies["culture"].Value = Session["Lang"].ToString();
            }
            ViewData["Message"] = null;
            return SearchSRInfo(ebdservicerequests, page, submit);
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public JsonResult GetProjectTitleByPrjCode(string prjCode)
        {
            List<string> projCtrInfo = new List<string>();
            string strQuery = string.Empty;

            //List<SelectListItem> list = new List<SelectListItem>();
            //IQueryable<ServiceType> queryable = from svcType in this.db.ServiceType
            //                                    where svcType.serviceTypeID != 4
            //                                    select svcType;
            //foreach (ServiceType current in ((IEnumerable<ServiceType>)queryable))
            //{
            //    list.Add(new SelectListItem
            //    {
            //        Text = current.serviceTypeDescription,
            //        Value = current.serviceTypeID.ToString()
            //    });
            //}

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString; 
                //strQuery = "SELECT ctr.Contract_No,Replace(prj.project_newname_en,',','') as project_newname_en,prj.project_code FROM PROJECTS prj INNER JOIN CONTRACTORS ctr ON " +
                //"prj.proj_id = ctr.proj_id WHERE prj.project_code like '%' + @SearchText + '%'";

                strQuery = "SELECT ctr.contract_no,Replace(prj.project_newname_en,',','') as project_newname_en,prj.project_code FROM PROJECTS prj INNER JOIN CONTRACTORS ctr ON " +
                "prj.proj_id = ctr.proj_id WHERE prj.project_code like '%' + @SearchText + '%'";

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = strQuery;
                    cmd.Parameters.AddWithValue("@SearchText", prjCode);
                    cmd.Connection = conn;
                    conn.Open();
                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        while (sdr.Read())
                        {
                            projCtrInfo.Add(string.Format("{0},{1},{2}", sdr["Contract_No"].ToString(), sdr["project_newname_en"].ToString(), sdr["project_code"].ToString()));
                            //projCtrInfo.Add(string.Format("{0}${1}", sdr["project_newname_en"].ToString(), sdr["project_code"].ToString()));
                            //customers.Add(string.Format("{0}-{1}", sdr["Contract_No"], sdr["bidder_ID"]));
                        }
                    }
                    conn.Close();
                }
            }
            return Json(projCtrInfo.ToArray(), JsonRequestBehavior.AllowGet);             
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public JsonResult GetProjectTitleByCtrNo(string ctrNo)
        {
            List<string> projCodeTitle = new List<string>();
            string strQuery = string.Empty;

            //List<SelectListItem> list = new List<SelectListItem>();
            //IQueryable<ServiceType> queryable = from svcType in this.db.ServiceType
            //                                    where svcType.serviceTypeID != 4
            //                                    select svcType;
            //foreach (ServiceType current in ((IEnumerable<ServiceType>)queryable))
            //{
            //    list.Add(new SelectListItem
            //    {
            //        Text = current.serviceTypeDescription,
            //        Value = current.serviceTypeID.ToString()
            //    });
            //}

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;
                strQuery = "SELECT prj.project_code,Replace(prj.project_newname_en,',','') as project_newname_en,ctr.contract_no FROM PROJECTS prj INNER JOIN CONTRACTORS ctr ON " +
                "prj.proj_id = ctr.proj_id WHERE ctr.Contract_No like '%' + @SearchText + '%'";

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = strQuery;
                    cmd.Parameters.AddWithValue("@SearchText", ctrNo);
                    cmd.Connection = conn;
                    conn.Open();
                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        while (sdr.Read())
                        {
                            projCodeTitle.Add(string.Format("{0},{1},{2}", sdr["project_code"].ToString(), sdr["project_newname_en"].ToString(), sdr["contract_no"].ToString()));
                            //customers.Add(string.Format("{0}-{1}", sdr["Contract_No"], sdr["bidder_ID"]));
                        }
                    }
                    conn.Close();
                }
            }
            return Json(projCodeTitle.ToArray(), JsonRequestBehavior.AllowGet);             
        }


        //public ActionResult SearchSurveyRqt(string submit, int? page, string emailID)
        //{
        //    ViewData["Message"] = null;
        //    return SearchSurveyReqInfo(submit, page, emailID);
        //}

        private ActionResult SearchSRInfo(EBDServiceRequests ebdservicerequests, int? page, string submit)
        {
            ActionResult actionResult = null;
            if(submit == null)
            {
                if (Request.Cookies["culture"] != null)
                {
                    if (Request.Cookies["culture"].Value == "en")
                    {
                        ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
                        ViewData["msg"] = "SEARCH SERVICE REQUEST";
                    }
                    else
                    {
                        ViewData["firstHeading"] = EBDServiceRequest.ResourceAr.firstHeading;
                        ViewData["msg"] = "طلب خدمة البحث"; 
                    }
                }
                else
                {
                    ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
                    ViewData["msg"] = "SEARCH SERVICE REQUEST";
                }                

                actionResult = DisplaySearchResults(ebdservicerequests, page, actionResult);
            }
            else if (submit.StartsWith("Search") || submit.StartsWith("بحث"))
            {
                actionResult = DisplaySearchResults(ebdservicerequests, page, actionResult);
            }
            else if (submit.StartsWith("Create") ||  submit.StartsWith("إنشاء"))
            {
                actionResult = RedirectToAction("CreateSR", "ServiceRequest");
            }
            else if (submit.StartsWith("Cancel") || submit.StartsWith("إلغاء"))
            {
                actionResult = RedirectToAction("ServiceRequest");
            }
            return actionResult;
        }

        //private ActionResult SearchSurveyReqInfo(string submit, int? page, string emailID)
        //{
        //    ActionResult actionResult = null;
        //    if (submit == null)
        //    {
        //        if (Request.Cookies["culture"] != null)
        //        {
        //            if (Request.Cookies["culture"].Value == "en")
        //            {
        //                ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
        //                ViewData["msg"] = "SEARCH SURVEY REQUEST";
        //            }
        //            else
        //            {
        //                ViewData["firstHeading"] = EBDServiceRequest.ResourceAr.firstHeading;
        //                ViewData["msg"] = "بحث طلب المسح";
        //            }
        //        }
        //        else
        //        {
        //            ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
        //            ViewData["msg"] = "SEARCH SURVEY REQUEST";
        //        }                

        //        if (emailID != null && page == null)
        //        {
        //            Session["emailID"] = emailID;                    
        //        }
        //        else
        //        {
        //            if (Session["emailID"] != null && page != null)
        //            {
        //                emailID = Session["emailID"].ToString();
        //            }
        //            else if (Session["emailID"] != null && page == null)
        //            {
        //                emailID = null;
        //            }
        //        }
        //        actionResult = DisplaySurveyResults(actionResult, page, emailID);
        //    }
        //    else if (submit.StartsWith("Create"))
        //    {
        //        actionResult = RedirectToAction("SurveyRequest", "ServiceRequest");
        //    }
        //    else if (submit.StartsWith("Cancel"))
        //    {
        //        actionResult = RedirectToAction("ServiceRequest");
        //    }               
        //    //else if (submit.StartsWith("Search"))
        //    //{
        //    //    actionResult = DisplaySearchResults(actionResult,page, emailID);
        //    //}
            
            
        //    return actionResult;
        //}


        private ActionResult DisplaySearchResults(EBDServiceRequests ebdservicerequests, int? page, ActionResult actionResult)
        {
            string emailID = null;
            if (ebdservicerequests.emailID != null)
            {
                TempData["EmailID"] = ebdservicerequests.emailID;
                emailID = TempData["EmailID"].ToString();
                ViewData["IsEmailID"] = true;
                @ViewData["EmailIDVal"] = emailID;
            }
            else
            {
                if (page != null)
                {
                    if (TempData["EmailID"] != null)
                    {
                        emailID = TempData["EmailID"].ToString();
                        ViewData["IsEmailID"] = true;
                        @ViewData["EmailIDVal"] = emailID;
                    }
                    else
                    {
                        actionResult = RedirectToAction("ServiceRequest");
                        return actionResult;
                    }
                }
                else
                {
                    TempData["EmailID"] = null;
                    emailID = null;
                    ViewData["IsEmailID"] = false;
                    @ViewData["EmailIDVal"] = emailID;
                }
            }

            TempData.Keep();

            // Get specific records using entity framework and LINQ queries.
            IQueryable<EBDServiceRequests> queryable = from svcRequest in this.db.EBDServiceRequests
                                                       where svcRequest.emailID == emailID
                                                       orderby svcRequest.serviceRequestDate descending
                                                       select svcRequest;

            //var queryable = (from svcRequest in this.db.EBDServiceRequests
            //                 join jStat in db.JobStatus on svcRequest.statusID equals jStat.jobStatusID
            //                where svcRequest.emailID == emailID
            //                orderby svcRequest.serviceRequestDate descending
            //                      select new 
            //                           {
            //                               empName = svcRequest.empName,
            //                               serviceRequestDate = svcRequest.serviceRequestDate,
            //                               serviceRequestDescription = svcRequest.serviceRequestDescription,
            //                               serviceReqNo = svcRequest.serviceReqNo,
            //                               jobStatusName = jStat.jobStatusName,
            //                               srExpectedDate = svcRequest.srExpectedDate
            //                           }).AsEnumerable().Select(
            //                 x => new 
            //                 {
            //                    empName = x.empName,
            //                    serviceRequestDate = Convert.ToDateTime(x.serviceRequestDate.GetValueOrDefault().ToString("dd/MMM/yyyy").Split(' ')[0]),
            //                    serviceRequestDescription = x.serviceRequestDescription,
            //                    serviceReqNo = x.serviceReqNo,
            //                    jobStatusName = x.jobStatusName,                   
            //                    srExpectedDate = Convert.ToDateTime(x.srExpectedDate.GetValueOrDefault().ToString("dd/MMM/yyyy"))
            //                }).ToList();

            //IQueryable<EBDServiceRequests> queryable1 = (IQueryable<EBDServiceRequests>) 
            //queryable.Select(r => new 
            //{
            //    empName = r.empName,        
            //    serviceRequestDate = r.serviceRequestDate.GetValueOrDefault().ToString("dd/MMM/yyyy"),
            //    serviceRequestDescription = r.serviceRequestDescription,
            //    serviceReqNo = r.serviceReqNo,
            //    jobStatusName = r.JobStatus.jobStatusName,
            //    srExpectedDate = r.srExpectedDate.GetValueOrDefault().ToString("dd/MMM/yyyy")         
            //});
                                                       //select new { x => new EBDServiceRequests() 
                                                       //{
                                                       //    empName = svcRequest.empName,
                                                       //    serviceRequestDate = svcRequest.serviceRequestDate 
                                                       //};                           

            int pageSize = 10;
            int pageIndex = 1;
            pageIndex = page.HasValue ? Convert.ToInt32(page) : 1;


            IPagedList<EBDServiceRequests> ebdServiceRequests = null;
            int? totalRecords = queryable.Count();

            if (totalRecords > 0)
            {
                ViewData["EmailIDNotFound"] = "Found";
                //queryable.Select(c => c.serviceRequestDate.Value.ToString("dd/MMM/yyyy").Split(' ')[0]);
                //queryable.Select(c => c.srExpectedDate.Value.ToString("dd/MMM/yyyy"));
                ebdServiceRequests = queryable.ToPagedList(pageIndex, pageSize);                
                actionResult = View(ebdServiceRequests);
            }
            else
            {
                if (emailID != null)
                {
                    ViewData["EmailIDNotFound"] = "No records found for the entered EmailID!";
                    ebdServiceRequests = queryable.ToPagedList(1, 1);
                }
                else if (emailID == null)
                {
                    ebdServiceRequests = queryable.ToPagedList(1, 1);
                }
                else
                {
                    ebdServiceRequests = queryable.ToPagedList(pageIndex, pageSize);
                }
                actionResult = View(ebdServiceRequests);
            }

            return actionResult;
        }

        //private ActionResult DisplaySurveyResults(ActionResult actionResult, int? page, string emailID)
        //{
        //    int totalRecords = 0;
        //    int pageSize = 10;
        //    int pageIndex = 1;
        //    IPagedList<SURVEY_INFO> survey_Info = null;
        //    IQueryable<SURVEY_INFO> queryable = null;
        //    pageIndex = page.HasValue ? Convert.ToInt32(page) : 1;
        //    //if (surveyInfo.REQUESTER_MAIL != null)
        //    //{
        //    //    TempData["EmailID"] = surveyInfo.REQUESTER_MAIL;
        //    //    emailID = TempData["EmailID"].ToString();
        //    //    ViewData["IsEmailID"] = true;
        //    //    @ViewData["EmailIDVal"] = emailID;
        //    //}
        //    //else
        //    //{
        //        if (emailID != null)
        //        {
        //            //emailID = TempData["EmailID"].ToString();
        //            //ViewData["IsEmailID"] = true;
        //            //@ViewData["EmailIDVal"] = emailID;
        //            queryable = from surInfo in this.db.SURVEY_INFO
        //                            where surInfo.REQUESTER_MAIL == emailID
        //                            orderby surInfo.REQUEST_ID descending
        //                            select surInfo;                        
        //            totalRecords = queryable.Count();                  
                    
        //        }
        //        else
        //        {
        //            //TempData["EmailID"] = null;
        //            emailID = null;
        //            //ViewData["IsEmailID"] = false;
        //            //@ViewData["EmailIDVal"] = emailID;
        //        }
        //    //}

        //    //TempData.Keep();

        //    // Get specific records using entity framework and LINQ queries.
           

        //    //var queryable = (from svcRequest in this.db.EBDServiceRequests
        //    //                 join jStat in db.JobStatus on svcRequest.statusID equals jStat.jobStatusID
        //    //                where svcRequest.REQUESTER_MAIL == emailID
        //    //                orderby svcRequest.serviceRequestDate descending
        //    //                      select new 
        //    //                           {
        //    //                               empName = svcRequest.empName,
        //    //                               serviceRequestDate = svcRequest.serviceRequestDate,
        //    //                               serviceRequestDescription = svcRequest.serviceRequestDescription,
        //    //                               serviceReqNo = svcRequest.serviceReqNo,
        //    //                               jobStatusName = jStat.jobStatusName,
        //    //                               srExpectedDate = svcRequest.srExpectedDate
        //    //                           }).AsEnumerable().Select(
        //    //                 x => new 
        //    //                 {
        //    //                    empName = x.empName,
        //    //                    serviceRequestDate = Convert.ToDateTime(x.serviceRequestDate.GetValueOrDefault().ToString("dd/MMM/yyyy").Split(' ')[0]),
        //    //                    serviceRequestDescription = x.serviceRequestDescription,
        //    //                    serviceReqNo = x.serviceReqNo,
        //    //                    jobStatusName = x.jobStatusName,                   
        //    //                    srExpectedDate = Convert.ToDateTime(x.srExpectedDate.GetValueOrDefault().ToString("dd/MMM/yyyy"))
        //    //                }).ToList();

        //    //IQueryable<EBDServiceRequests> queryable1 = (IQueryable<EBDServiceRequests>) 
        //    //queryable.Select(r => new 
        //    //{
        //    //    empName = r.empName,        
        //    //    serviceRequestDate = r.serviceRequestDate.GetValueOrDefault().ToString("dd/MMM/yyyy"),
        //    //    serviceRequestDescription = r.serviceRequestDescription,
        //    //    serviceReqNo = r.serviceReqNo,
        //    //    jobStatusName = r.JobStatus.jobStatusName,
        //    //    srExpectedDate = r.srExpectedDate.GetValueOrDefault().ToString("dd/MMM/yyyy")         
        //    //});
        //    //select new { x => new EBDServiceRequests() 
        //    //{
        //    //    empName = svcRequest.empName,
        //    //    serviceRequestDate = svcRequest.serviceRequestDate 
        //    //};
        //    if (totalRecords > 0)
        //    {                
        //        survey_Info = queryable.ToPagedList(pageIndex, pageSize);
        //        actionResult = View(survey_Info);
        //    }
        //    else
        //    {                 
        //        survey_Info = queryable.ToPagedList(1, 1);                
        //        actionResult = View(survey_Info);
        //    }

        //    return actionResult;
        //}

        //private ActionResult DisplaySearchResults(ActionResult actionResult, int? page, string emailID)
        //{           
        //    if (emailID != null)
        //    {
        //        DataTable dt = GetData("select project_name as \"Project Name\",to_char(REQUEST_TIME,'dd/Mon/yyyy') as \"Date of Request\",to_char(EXPECTED_COMP_DATE,'dd/Mon/yyyy') as \"Expected Completion Date\",PURPOSE as Purpose,STATUS as Status," +
        //        "request_id from SURVEY_INFO where REQUESTER_MAIL='" + HttpUtility.HtmlDecode(emailID) + "' and (project_name<>'' or project_name is not Null) order by REQUEST_ID desc", false);

        //        SearchSurveyRequest search = new SearchSurveyRequest();
        //        List<ViewSurveyRequest> lstSR = new List<ViewSurveyRequest>();
        //        if (dt != null)
        //        {
        //            if (dt.Rows.Count > 0)
        //            {
        //                foreach (DataRow item in dt.Rows)
        //                {
        //                    string reqTime = "";
        //                    if (item["Date of Request"] != null)
        //                    {
        //                        if (item["Date of Request"].ToString() != "")
        //                        {
        //                            reqTime = item["Date of Request"].ToString(); // Convert.ToDateTime(item["Date of Request"]).ToString();//.ToString("dd/MM/yyyy");
        //                        }
        //                    }
        //                    string expCompDate = "";
        //                    if (item["Expected Completion Date"] != null)
        //                    {                                
        //                        if (item["Expected Completion Date"].ToString() != "")
        //                        {
        //                            expCompDate = item["Expected Completion Date"].ToString(); // Convert.ToDateTime(item["Expected Completion Date"].ToString()).ToString();
        //                        } 
        //                    }
        //                    lstSR.Add(new ViewSurveyRequest
        //                    {
        //                        Project_Name = item["Project Name"].ToString(),
        //                        Request_Time = reqTime,
        //                        Expected_Comp_Date = expCompDate,
        //                        Purpose = item["Purpose"].ToString(),
        //                        Status = item["Status"].ToString(),
        //                        Request_Id = item["request_id"].ToString()
        //                    });
                             
        //                }
        //            }
        //            else
        //            {                        
        //                ViewData["EmailIDNotFound"] = "No records found for the entered EmailID!";
        //            }
        //        }                 
                
        //        if (page == null)
        //        {
        //            search.listVSR = lstSR.ToPagedList(1, 10);
        //        }
        //        else
        //        {
        //            search.listVSR = lstSR.ToPagedList((int)page, 10);
        //        }
        //        actionResult = View(search);                 
                
        //    }
        //    else
        //    {
        //        DataTable dtSurveyRequests = new DataTable();
        //        dtSurveyRequests.Columns.Add("Project Name");
        //        dtSurveyRequests.Columns.Add("Date of Request");
        //        dtSurveyRequests.Columns.Add("Expected Completion Date");
        //        dtSurveyRequests.Columns.Add("Purpose");
        //        dtSurveyRequests.Columns.Add("Status");
        //        dtSurveyRequests.Columns.Add("RequestId");
        //        dtSurveyRequests.AcceptChanges();                 

        //        SearchSurveyRequest search = new SearchSurveyRequest();                 
        //        actionResult = View(search);                 
        //    }
             
        //    return actionResult;
        //}

        // GET: /ServiceRequest/ViewSR/5
        public ActionResult ViewSR(int? id, string submit, string emailID, string lang)
        {
            if (lang != null)
            {                 
                Request.Cookies["culture"].Value = lang;
                //if (lang == "Ar")
                //{
                //    new ManageLanguage().SetLanguage("Arabic");

                //}
                //else if (lang == "en")
                //{
                //    new ManageLanguage().SetLanguage("English");
                //}
            }
            EBDServiceRequests ebdservicerequests = db.EBDServiceRequests.Find(id);
            ActionResult viewObj = null;
            if (submit == null)
            {
                if (id == null)
                {                    
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest); 
                }
                
                if (ebdservicerequests == null)
                {
                    return HttpNotFound();
                }
                SetDepartment(ebdservicerequests);
                SetSection(ebdservicerequests);
                FillAndSetServiceType(ebdservicerequests, true);
                FillAndSetServiceTypeSubCategory(ebdservicerequests.serviceTypeID, ebdservicerequests.serviceTypeSystemID, true);                 
                //ViewBag.FilePath = ebdservicerequests.filePath;
                DataTable dtFilePath = new DataTable();
                dtFilePath.Columns.Add("FileName", typeof(string));
                dtFilePath.Columns.Add("FilePath", typeof(string));
                dtFilePath.AcceptChanges();

                if (ebdservicerequests.filePath != "" && ebdservicerequests.filePath !=null)
                {                    
                    DirectoryInfo dirInfo = new DirectoryInfo(ebdservicerequests.filePath);
                    if (dirInfo.Exists != false)
                    {
                        FileInfo[] files = dirInfo.GetFiles("*.*");

                        foreach (FileInfo file in files)
                        {
                            DataRow dr = dtFilePath.NewRow();
                            dr["FileName"] = file.Name;
                            dr["FilePath"] = file.FullName;
                            dtFilePath.Rows.Add(dr);
                            dtFilePath.AcceptChanges();
                        }                        
                    }
                    else
                    {
                        ViewData["IsVisible"] = "hidden";
                    }
                    ViewData["FilesInfo"] = dtFilePath;
                }
                else
                {
                    ViewData["IsVisible"] = "hidden";
                    ViewData["FilesInfo"] = dtFilePath;
                }
                //ebdservicerequests.serviceRequestDate = Convert.ToDateTime(ebdservicerequests.serviceRequestDate.Value.ToString("dd-MMM-yyyy"));
                if (Request.Cookies["culture"] != null)
                {
                    if (Request.Cookies["culture"].Value == "en")
                    {
                        ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
                        ViewData["msg"] = "VIEW SERVICE REQUEST";
                    }
                    else
                    {
                        ViewData["firstHeading"] = EBDServiceRequest.ResourceAr.firstHeading;
                        ViewData["msg"] = "عرض طلب الخدمة";
                    }
                }
                else
                {
                    ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
                    ViewData["msg"] = "VIEW SERVICE REQUEST";
                }                 
                viewObj = View(ebdservicerequests); 
            }
            else if (submit !=null)
            {
                if(submit.StartsWith("Create") || submit.StartsWith("إنشاء"))
                {
                    viewObj = RedirectToAction("CreateSR", "ServiceRequest");
                }
                else if (submit.StartsWith("Search") || submit.StartsWith("بحث"))
                {
                    return RedirectToAction("SearchSR", "ServiceRequest");
                }                
            }         

            return viewObj;
            
        }



        //public ActionResult ViewSurveyRqt(int? id)
        //{
        //    SURVEY_INFO surInfo = db.SURVEY_INFO.Find(id);
        //    //SetSessionVariables();
        //    if (Request.Cookies["culture"] != null)
        //    {
        //        if (Request.Cookies["culture"].Value == "en")
        //        {
        //            ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
        //            ViewData["msg"] = "VIEW SURVEY REQUEST";
        //        }
        //        else
        //        {
        //            ViewData["firstHeading"] = EBDServiceRequest.ResourceAr.firstHeading;
        //            ViewData["msg"] = "عرض طلب المسح";
        //        }
        //    }
        //    else
        //    {
        //        ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
        //        ViewData["msg"] = "VIEW SURVEY REQUEST";
        //    }  
            
        //    ActionResult viewObj = null;
        //    //DataTable dt = GetData("select REQUESTER_MAIL,Project_No,project_name,PRIORITY,REQUEST_TIME,EXPECTED_COMP_DATE,PURPOSE,STATUS,WORKQTY,REFNO,Description,REQUESTER_DEPT," +
        //    //"CONTRACTOR_NAME,request_id from SURVEY_INFO where REQUEST_ID=" + id + " order by REQUEST_ID desc", false);
        //    //SearchSurveyRequest search = new SearchSurveyRequest();
        //    //List<ViewSurveyRequest> lstSR = new List<ViewSurveyRequest>();
        //    //if (dt != null)
        //    //{
        //    //    if (dt.Rows.Count > 0)
        //    //    {
        //    //        foreach (DataRow item in dt.Rows)
        //    //        {
        //    //            lstSR.Add(new ViewSurveyRequest
        //    //            {
        //    //                EmailID = item["REQUESTER_MAIL"].ToString(),
        //    //                Project_No = item["Project_No"].ToString(),
        //    //                Project_Name = item["project_name"].ToString(),
        //    //                Priority = item["PRIORITY"].ToString(),
        //    //                Request_Time = item["REQUEST_TIME"].ToString(),
        //    //                Expected_Comp_Date = item["EXPECTED_COMP_DATE"].ToString(),
        //    //                Purpose = item["Purpose"].ToString(),
        //    //                Status = item["Status"].ToString(),
        //    //                WorkQty = item["WORKQTY"].ToString(),
        //    //                RefNo = item["REFNO"].ToString(),
        //    //                Description = item["Description"].ToString(),
        //    //                ContractorName = item["CONTRACTOR_NAME"].ToString(),
        //    //                DepartmentName = item["REQUESTER_DEPT"].ToString(),
        //    //                Request_Id = item["request_id"].ToString()
        //    //            });

        //    //        }                    
        //    //    }
        //    //    else
        //    //    {
        //    //        ViewData["ExcepMessage"] = "No records found for the selected Request ID!";
        //    //    }                
        //    //}
        //    Session["requestID"] = id;
        //    ViewData["createSRDisabled"] = true;
        //    //search.listVSR = lstSR.ToPagedList(1,10);
        //    viewObj = View(surInfo);

        //    //EBDServiceRequests ebdservicerequests = db.EBDServiceRequests.Find(id);
        //    //ActionResult viewObj = null;
        //    //if (submit == null)
        //    //{
        //    //    if (id == null)
        //    //    {
        //    //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    //    }

        //    //    if (ebdservicerequests == null)
        //    //    {
        //    //        return HttpNotFound();
        //    //    }
        //    //    SetDepartment(ebdservicerequests);
        //    //    SetSection(ebdservicerequests);
        //    //    FillAndSetServiceType(ebdservicerequests, true);
        //    //    FillAndSetServiceTypeSubCategory(ebdservicerequests.serviceTypeID, ebdservicerequests.serviceTypeSystemID, true);
        //    //    //ViewBag.FilePath = ebdservicerequests.filePath;
        //    //    DataTable dtFilePath = new DataTable();
        //    //    dtFilePath.Columns.Add("FileName", typeof(string));
        //    //    dtFilePath.Columns.Add("FilePath", typeof(string));
        //    //    dtFilePath.AcceptChanges();

        //    //    if (ebdservicerequests.filePath != "" && ebdservicerequests.filePath != null)
        //    //    {
        //    //        DirectoryInfo dirInfo = new DirectoryInfo(ebdservicerequests.filePath);
        //    //        if (dirInfo.Exists != false)
        //    //        {
        //    //            FileInfo[] files = dirInfo.GetFiles("*.*");

        //    //            foreach (FileInfo file in files)
        //    //            {
        //    //                DataRow dr = dtFilePath.NewRow();
        //    //                dr["FileName"] = file.Name;
        //    //                dr["FilePath"] = file.FullName;
        //    //                dtFilePath.Rows.Add(dr);
        //    //                dtFilePath.AcceptChanges();
        //    //            }
        //    //        }
        //    //        else
        //    //        {
        //    //            ViewData["IsVisible"] = "hidden";
        //    //        }
        //    //        ViewData["FilesInfo"] = dtFilePath;
        //    //    }
        //    //    else
        //    //    {
        //    //        ViewData["IsVisible"] = "hidden";
        //    //        ViewData["FilesInfo"] = dtFilePath;
        //    //    }
        //    //    //ebdservicerequests.serviceRequestDate = Convert.ToDateTime(ebdservicerequests.serviceRequestDate.Value.ToString("dd-MMM-yyyy"));

        //    //    viewObj = View(ebdservicerequests);
        //    //}
        //    //else if (submit != null)
        //    //{
        //    //    if (submit.StartsWith("Search"))
        //    //    {
        //    //        viewObj = RedirectToAction("SearchSurveyReq", "ServiceRequest");
        //    //    }
        //    //    else if (submit.StartsWith("Cancel"))
        //    //    {
        //    //        viewObj = RedirectToAction("ServiceRequest", "ServiceRequest");
        //    //    }     
        //    //}

        //    return viewObj;

        //}

        public DataTable GetData(string sql, bool isOrdered)
        {
            DataTable dt = null;
            OracleDataAdapter da = null;
            DataSet ds = null;
            ds = new DataSet();
            OracleConnection con = new OracleConnection(System.Configuration.ConfigurationManager.ConnectionStrings["SurveyConnOracle"].ConnectionString);
            try
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con.Open();
                da = new OracleDataAdapter(sql, con);
                da.Fill(ds);
                con.Dispose();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            if (!isOrdered)
            {
                if (ds.Tables[0].Rows.Count != 0)
                {
                    dt = ds.Tables[0].AsEnumerable().CopyToDataTable();
                }
                else
                {
                    if (sql.Contains("project_name"))
                    {
                        DataTable dtSurveyRequests = new DataTable();
                        dtSurveyRequests.Columns.Add("Project Name");
                        dtSurveyRequests.Columns.Add("Date of Request");
                        dtSurveyRequests.Columns.Add("Expected Completion Date");
                        dtSurveyRequests.Columns.Add("Purpose");
                        dtSurveyRequests.Columns.Add("Status");
                        dtSurveyRequests.Columns.Add("RequestId");
                        dtSurveyRequests.AcceptChanges();
                        dt = dtSurveyRequests;
                    }
                }
            }
            else
            {
                if (ds.Tables[0].Rows.Count != 0)
                {
                    dt = ds.Tables[0].AsEnumerable().CopyToDataTable();
                    dt.DefaultView.Sort = "requester_dept ASC";
                }
            }

            return dt;
        }


        private void FillDropDownListsControls()
        {
            //FillJobTypes();            
            FillContractors();
            //FillDeptOraDB();            
            FillDepartments();
            FillPriority();
            FillUnits();
        }

        private void SetSessionVariables()
        {
            //Session["requestID"] = null;
            Session["ArcGISDynamicMapServiceLayerUrl"] = ConfigurationManager.AppSettings["ArcGISDynamicMapServiceUrl"].ToString();
            Session["CadastralPlotsServiceUrl"] = ConfigurationManager.AppSettings["CadastralPlotsServiceUrl"].ToString();
            Session["Control95ServiceUrl"] = ConfigurationManager.AppSettings["Control95ServiceUrl"].ToString();
            Session["PolicyPlanPlotServiceUrl"] = ConfigurationManager.AppSettings["PolicyPlanPlotServiceUrl"].ToString();
            Session["RoadsDivertedServiceUrl"] = ConfigurationManager.AppSettings["RoadsDivertedServiceUrl"].ToString();
            Session["RoadsClosedServiceUrl"] = ConfigurationManager.AppSettings["RoadsClosedServiceUrl"].ToString();
            Session["RoadsOpenedServiceUrl"] = ConfigurationManager.AppSettings["RoadsOpenedServiceUrl"].ToString();
            Session["RoadsConstServiceUrl"] = ConfigurationManager.AppSettings["RoadsConstServiceUrl"].ToString();
            Session["ImageServiceUrl"] = ConfigurationManager.AppSettings["ImageServiceUrl"].ToString();            
            Session["FeatureLayerUrl"] = ConfigurationManager.AppSettings["FeatureLayerUrl"].ToString();
            Session["GeoProcessorUrl"] = ConfigurationManager.AppSettings["GeoProcessorUrl"].ToString();
        }

        //// GET: /ServiceRequest/CreateSR
        public ActionResult CreateSRWithMap()
        {
            SetSessionVariables();
            ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
            ViewData["msg"] = "SURVEY REQUEST";
            //Session["requestID"] = null;
            //FillDropDownListsControls();
            //ViewData["ProjectCode"] = "";
            //ViewDat a["ContractNo"] = "";
            //ViewData["Quantity"] = "";
            //ViewData["DocRefNo"] = "";
            //ViewData["ProjectTitle"] = "";
            //ViewData["DescripAreaVal"] = "";
            //if (Session["requestID"] == null)
            //{
            //    ViewData["createSRDisabled"] = false;
            //}
            //this.SetDisbaledProperties(false);
            //EBDServiceRequests ebdServiceRequests = new EBDServiceRequests();
            //ebdServiceRequests.serviceRequestDate = new DateTime?(DateTime.Now);
            //this.FillDepartment();
            //this.FillSections();
            //this.FillServiceTypes();
            //this.FillAndSetServiceTypeSubCategory(1, 0, false);
            return base.View();
        }

        //public ActionResult ViewSurveyReq()
        //{
        //    ViewData["msg"] = "SURVEY REQUEST";
        //    //ViewData["IsReqEmailIDDisabled"] = false;
        //    //Session["requestID"] = null;
        //    FillDropDownListsControls();

        //    if (Session["IsRedirect"] == null)
        //    {
        //        Session["reqEmailID"] = null;
        //        Session["ctrEmailID"] = null;
        //        Session["Priority"] = null;
        //        Session["JobType"] = null;
        //        Session["Contractor"] = null;
        //        Session["ContractorID"] = null;
        //        Session["ProjectCode"] = null;
        //        Session["ContractNo"] = null;
        //        Session["Quantity"] = null;
        //        Session["DocRefNo"] = null;
        //        Session["ProjectTitle"] = null;
        //        Session["DescripAreaVal"] = null;
        //        Session["QuantityUnit"] = "Kms";
        //    }
        //    return base.View();
        //}

        public ActionResult SurveyRequest(int? id)
        {            
            //ViewData["IsReqEmailIDDisabled"] = false;
            //Session["requestID"] = null;
             
            FillDropDownListsControls();
             
            
            //ViewData["IsOtherDeptVisible"] = "hidden";
            //ViewData["IsOtherContractorVisible"] = "hidden";
            if (Session["DepartmentID"] != null)
            {
                if (Session["DepartmentID"].ToString() == "Other")
                {

                    ViewData["IsOtherDeptVisible"] = "visibility:visible";
                }
                else
                {
                    ViewData["IsOtherDeptVisible"] = "display:none";
                }
            }
            else
            {
                ViewData["IsOtherDeptVisible"] = "display:none";
            }

            if (Session["Contractor"] != null)
            {
                if (Session["Contractor"].ToString() == "Other")
                {
                    ViewData["IsOtherContractorVisible"] = "visibility:visible";
                }
                else
                {
                    ViewData["IsOtherContractorVisible"] = "display:none";
                }
            }
            else
            {
                ViewData["IsOtherContractorVisible"] = "display:none";
            }

            if (Session["IsRedirect"] == null && id==null)
            {
                if (Request.Cookies["culture"] != null)
                {
                    if (Request.Cookies["culture"].Value == "en")
                    {
                        ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
                        ViewData["msg"] = "SURVEY REQUEST";
                    }
                    else
                    {
                        ViewData["firstHeading"] = EBDServiceRequest.ResourceAr.firstHeading;
                        ViewData["msg"] = "طلب مسح";
                    }
                }
                else
                {
                    ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
                    ViewData["msg"] = "SURVEY REQUEST";
                }                               
                Session["requestID"] = null;
                Session["reqEmailID"] = null;
                Session["empName"] = null;
                Session["ctrEmailID"] = null;
                Session["Departmnet"] = null;
                Session["Priority"] = null;
                Session["JobType"] = null;
                Session["Contractor"] = null;
                Session["ContractorID"] = null;
                Session["ProjectCode"] = null;
                Session["ContractNo"] = null;
                Session["Quantity"] = null;
                Session["DocRefNo"] = null;
                Session["ProjectTitle"] = null;
                Session["DescripAreaVal"] = null;
                Session["ContractNo"] = null;
                Session["QuantityUnit"] = "Kms";
                Session["IsValidate"] = "visible";
                Session["ButtonName"] = "Create Polygon";                 
            }
            else
            {
                if (Request.Cookies["culture"] != null)
                {
                    if (Request.Cookies["culture"].Value == "en")
                    {
                        ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
                        ViewData["msg"] = "VIEW SURVEY REQUEST";
                    }
                    else
                    {
                        ViewData["firstHeading"] = EBDServiceRequest.ResourceAr.firstHeading;
                        ViewData["msg"] = "عرض طلب المسح";
                    }
                }
                else
                {
                    ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
                    ViewData["msg"] = "VIEW SURVEY REQUEST";
                }                 
                Session["IsValidate"] = "hidden";                
                      
                     try
                     {
                        if (id == null)
                        {
                             if (Session["IsSuccess"] != null)
                             {
                                 if (Session["requestID"] != null)
                                 {
                                     id = Convert.ToInt32(Session["requestID"]);
                                 }                                 
                             }
                             else
                             {
                                 if (Session["requestID"] != null)
                                 {
                                     id = Convert.ToInt32(Session["requestID"]);
                                 }
                                 //SetSessionVariablesFromTabData(id);                                  
                                 //dt = GetData("select REQUESTER_MAIL,REQUESTER_NAME,Project_No,project_name,PRIORITY,PURPOSE,STATUS,WORKQTY,REFNO,Description,REQUESTER_DEPT," +
                                 //"CONTRACTOR_NAME,CONTRACTORID,CONTRACTOR_EMAILID,CONTRACTNO,QUANTITYUNIT from SURVEY_INFO where REQUEST_ID=" + id + " order by REQUEST_ID desc", false);                             
                             }
                        }
                        else
                        {
                            //SetSessionVariablesFromTabData(id);
                            Session["requestID"] = id;
                        }
                        Session["ButtonName"] = "Next";
                        //ActionResult viewObj = null;              
                   

                        //SearchSurveyRequest search = new SearchSurveyRequest();
                        //List<ViewSurveyRequest> lstSR = new List<ViewSurveyRequest>();
                        //if (dt != null)
                        //{
                        //    if (dt.Rows.Count > 0)
                        //    {
                        //        foreach (DataRow item in dt.Rows)
                        //        {
                                    //lstSR.Add(new ViewSurveyRequest
                                    //{
                                    //Session["reqEmailID"] = item["REQUESTER_MAIL"].ToString();
                                    //Session["empName"] = item["REQUESTER_NAME"].ToString();
                                    //Session["ProjectCode"] = item["Project_No"].ToString();
                                    //Session["ProjectTitle"] = item["project_name"].ToString();
                                    //Session["Priority"] = item["PRIORITY"].ToString();
                                    //Session["Priority"] = item["REQUEST_TIME"].ToString();
                                    //Session["JobType"] = item["PURPOSE"].ToString();
                                    //Session["QuantityUnit"] = item["UNITS"].ToString();
                                    //Session["DepartmentID"] = item["REQUESTER_DEPT"].ToString();
                                    //Session["Contractor"] = item["CONTRACTOR_NAME"].ToString();
                                    //Session["ContractorID"] = item["CONTRACTORID"].ToString();
                                    //Session["DescripAreaVal"] = item["Description"].ToString();
                                    //Session["ContractorID"] = item["CONTRACTORID"].ToString();
                                    //Session["DocRefNo"] = item["REFNO"].ToString();
                                    //Session["ctrEmailID"] = item["CONTRACTOR_EMAILID"].ToString();
                                    //Session["Quantity"] = item["WORKQTY"].ToString();
                                    //Session["ContractNo"] = item["CONTRACTNO"].ToString();
                                    //Session["QuantityUnit"] = item["QUANTITYUNIT"].ToString();
                                   
                                    //Project_Name = item["project_name"].ToString(),
                                    //Priority = item["PRIORITY"].ToString(),
                                    //Request_Time = item["REQUEST_TIME"].ToString(),
                                    //Expected_Comp_Date = item["EXPECTED_COMP_DATE"].ToString(),
                                    //Purpose = item["Purpose"].ToString(),
                                    //Status = item["Status"].ToString(),
                                    //WorkQty = item["WORKQTY"].ToString(),
                                    //RefNo = item["REFNO"].ToString(),
                                    //Description = item["Description"].ToString(),
                                    //ContractorName = item["CONTRACTOR_NAME"].ToString(),
                                    //DepartmentName = item["REQUESTER_DEPT"].ToString(),
                                    //Request_Id = item["request_id"].ToString()
                                    //});

                        //        }
                        //    }                         
                        //}
                    }
                    catch (Exception ex)
                    {
                        ViewData["ExcepMessage"] = "Error occurred while retrieving the information.";                         
                    }                                                  
                    
                }
                //ViewData["createSRDisabled"] = true;
                //search.listVSR = lstSR.ToPagedList(1, 10);
                //viewObj = View();

            
            //Session["validateEmailID"] = false;
            //if (Session["reqEmailID"] != null)
            //{
            //    ViewData["reqEmailID"] = Session["reqEmailID"];
            //}
            //else
            //{
            //    ViewData["reqEmailID"] = "";
            //}
            
            //if (Session["DepartmentID"] != null)
            //{             
            //    ViewData["Department"] = Session["DepartmentID"];
            //}
            //else
            //{
            //    ViewData["Department"] = "";
            //}

            //if (Session["Priority"] != null)
            //{
            //     ViewData["Priority"] = Session["Priority"];             
            //}
            //else
            //{
            //    ViewData["Priority"] = "";
            //}

            //if (Session["JobType"] != null)
            //{
            //    ViewData["JobType"] = Session["JobType"];              
            //}
            //else
            //{
            //    ViewData["JobType"] = "";
            //}
            //if (Session["Contractor"] != null) 
            //{
            //    ViewData["Contractor"] = Session["Contractor"];              
            //}
            //else
            //{
            //    ViewData["Contractor"] = "";
            //}

            //if (Session["ContractorID"] != null)
            //{
            //    ViewData["ContractorID"] = Session["ContractorID"];
            //}
            //else
            //{
            //    ViewData["ContractorID"] = "";
            //}

            //if (Session["ProjectCode"] != null)
            //{
            //    ViewData["ProjectCode"] = Session["ProjectCode"];
            //}
            //else
            //{
            //    ViewData["ProjectCode"] = "";
            //}
            //if (Session["ContractNo"] != null)
            //{
            //    ViewData["ContractNo"] = Session["ContractNo"];
            //}
            //else
            //{
            //    ViewData["ContractNo"] = "";
            //}
            //if (Session["Quantity"] != null)
            //{
            //    ViewData["Quantity"] = Session["Quantity"];
            //}
            //else
            //{
            //    ViewData["Quantity"] = "";
            //}
            //if (Session["DocRefNo"] != null)
            //{
            //    ViewData["DocRefNo"] = Session["DocRefNo"];
            //}
            //else
            //{
            //    ViewData["DocRefNo"] = "";
            //}
            //if (Session["ProjectTitle"] != null)
            //{
            //    ViewData["ProjectTitle"] = Session["ProjectTitle"];
            //}
            //else
            //{
            //    ViewData["ProjectTitle"] = "";
            //}
            //if (Session["DescripAreaVal"] != null)
            //{
            //    ViewData["DescripAreaVal"] = Session["DescripAreaVal"];
            //}
            //else
            //{
            //    ViewData["DescripAreaVal"] = "";
            //}
            //if (Session["QuantityUnit"] != null)
            //{
            //    ViewData["Unit"] = Session["QuantityUnit"];
            //}
            //else
            //{
            //    ViewData["Unit"] = "";
            //}           
            

            if (Session["requestID"] != null)
            {
                DirectoryInfo dirInfo = new DirectoryInfo(ConfigurationManager.AppSettings["SurveyFolderPath"].ToString() + "\\Year_" + DateTime.Now.Year + "\\" + Session["requestID"]
                + "\\ApplicantData"); //+ "\\" + Session["ServiceReqNo"].ToString()
                ArrayList lstAppData = new ArrayList();
                if (dirInfo.Exists != false)
                {               
                    FileInfo[] files = dirInfo.GetFiles("*" + Session["requestID"] + "_*.*");
                   
                    foreach (FileInfo file in files)
                    {
                        //DataRow dr = dtFilePath.NewRow(); 
                        //dr["FileName"] = file.Name;
                        //dr["FilePath"] = file.FullName;
                        //dtFilePath.Rows.Add(dr);
                        //dtFilePath.AcceptChanges();
                        lstAppData.Add(file.Name + "," + file.FullName);
                    }                    
                }
                
                
                //Session["ApplicantFilesInfo"] = (DataTable)dtFilePath;
                ViewBag.ApplicantFilesInfo = lstAppData;

                ArrayList lstFinal = new ArrayList();
                dirInfo = new DirectoryInfo(ConfigurationManager.AppSettings["SurveyFolderPath"].ToString() + "\\Year_" + DateTime.Now.Year + "\\" + Session["requestID"]
                + "\\Final"); //+ "\\" + Session["ServiceReqNo"].ToString()
                if (dirInfo.Exists != false)
                {               
                    FileInfo[] files = dirInfo.GetFiles("*" + Session["requestID"] + "_*.*");                    
                    foreach (FileInfo file in files)
                    {
                        //DataRow dr = dtFilePath.NewRow(); 
                        //dr["FileName"] = file.Name;
                        //dr["FilePath"] = file.FullName;
                        //dtFilePath.Rows.Add(dr);
                        //dtFilePath.AcceptChanges();
                        lstFinal.Add(file.Name + "," + file.FullName);
                    }                    
                }
                ViewBag.FinalFilesInfo = lstFinal;      
          
                if(lstAppData.Count==0 && lstFinal.Count ==0)
                {
                    ViewData["IsVisible"] = "hidden";
                }
            }            
           
            

            
            //ViewData["createSRDisabled"] = true;
            return View();
            //return View();
            //Session["emailID"] = form[1];
            //Session["JobType"] = form[2];
            ////Session.SelectedItem = form[2];
            //Session["ProjectCode"] = form[3];
            //Session["Quantity"] = form[4];
            //Session["Contractor"] = form[5];
            //Session["DepartmentID"] = form[6];
            //Session["Priority"] = form[8];
            //Session["DocRefNo"] = form[7];
            //Session["ProjectTitle"] = form[9];
            //Session["DescripAreaVal"] = form[10];
            //return RedirectToAction("CreateSRWithMap", "ServiceRequest");

        }

        //private void SetSessionVariablesFromTabData(int? id)
        //{
        //    var queryable = (from data in db.SURVEY_INFO
        //                         .Where(row => row.REQUEST_ID == id)
        //                         .Select(row => new
        //                         {
        //                             REQUESTER_MAIL = row.REQUESTER_MAIL,
        //                             REQUESTER_NAME = row.REQUESTER_NAME,
        //                             PROJECT_NO = row.PROJECT_NO,
        //                             PROJECT_NAME = row.PROJECT_NAME,
        //                             PRIORITY = row.PRIORITY,
        //                             PURPOSE = row.PURPOSE,
        //                             REQUESTER_DEPT = row.REQUESTER_DEPT,
        //                             CONTRACTOR_NAME = row.CONTRACTOR_NAME,
        //                             CONTRACTORID = row.CONTRACTORID,
        //                             DESCRIPTION = row.DESCRIPTION,
        //                             REFNO = row.REFNO,
        //                             CONTRACTOR_EMAILID = row.CONTRACTOR_EMAILID,
        //                             WORKQTY = row.WORKQTY,
        //                             CONTRACTNO = row.CONTRACTNO,
        //                             QUANTITYUNIT = row.QUANTITYUNIT
        //                         })
        //                     select data);
        //    //IQueryable<SURVEY_INFO> queryable = null;                                  

        //    //var dt = queryable.FirstorDefault();
        //    foreach (var row in queryable)
        //    {
        //        Session["reqEmailID"] = row.REQUESTER_MAIL;
        //        Session["empName"] = row.REQUESTER_NAME;
        //        Session["ProjectCode"] = row.PROJECT_NO;
        //        Session["ProjectTitle"] = row.PROJECT_NAME;
        //        Session["Priority"] = row.PRIORITY;
        //        //Session["Priority"] = item["REQUEST_TIME"].ToString();
        //        Session["JobType"] = row.PURPOSE;
        //        //Session["QuantityUnit"] = item["UNITS"].ToString();
        //        Session["DepartmentID"] = row.REQUESTER_DEPT;
        //        Session["Contractor"] = row.CONTRACTOR_NAME;
        //        Session["ContractorID"] = row.CONTRACTORID;
        //        Session["DescripAreaVal"] = row.DESCRIPTION;
        //        Session["ContractorID"] = row.CONTRACTORID;
        //        Session["DocRefNo"] = row.REFNO;
        //        Session["ctrEmailID"] = row.CONTRACTOR_EMAILID;
        //        Session["Quantity"] = row.WORKQTY;
        //        Session["ContractNo"] = row.CONTRACTNO;
        //        Session["QuantityUnit"] = row.QUANTITYUNIT; 
        //    }
        //}

        [HttpPost]
        //[ValidateAntiForgeryToken]
        //[ValidateHeaderAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult SurveyRequest(FormCollection form, string submit, HttpPostedFileBase[] files)
        {
            ActionResult actionResult = null;
            SetSurveyReqSecondHeading();
            try
            {            
                if (submit.StartsWith("Validate"))                  
                {
                    ViewData["IsOtherDeptVisible"] = "display:none";
                    ViewData["IsOtherContractorVisible"] = "display:none";

                    //this.SetDisbaledProperties(false);      
                    FillDropDownListsControls();                
                    //ViewData["ProjectCode"] = "";
                    //ViewData["ContractNo"] = "";
                    //ViewData["Quantity"] = "";
                    //ViewData["DocRefNo"] = "";
                    //ViewData["ProjectTitle"] = "";
                    //ViewData["DescripAreaVal"] = "";

                    Session["ProjectCode"] = "";
                    Session["ContractNo"] = "";
                    Session["Quantity"] = "";
                    Session["DocRefNo"] = "";
                    Session["ProjectTitle"] = "";
                    Session["DescripAreaVal"] = "";
                    //FillUnits();
                    //ViewData["Unit"] = "SqKms";
                    IQueryable<Contact> queryable = null;
                    string emailID = form[0];
                    queryable = from c in this.db.Contact
                                where c.emailAddress == emailID
                                select c;
                    if (queryable.Count<Contact>() > 0)
                    {
                        Session["ContactID"] = queryable.Select(t => t.contactID).AsEnumerable<int>().First<int>();
                        Session["empName"] = GetNameAndSetDeptFromAD(emailID);                         
                        Session["reqEmailID"] = emailID;
                        Session["validateEmailID"] = true;
                        Session["IsReqEmailIDDisabled"] = true;
                    }
                    else
                    {
                        //using (var db = new eBookUnitTestDBEntities())
                        //{
                        //    db.Contact.Add(new Contact { firstName = TempData["FirstName"].ToString(), lastName = TempData["LastName"].ToString(),
                        //    companyID = });
                        //   db.SaveChanges();
                        //}

                        //DisplayCreateSR(serviceTypeID, serviceTypeSystemID, ebdservicerequests);                    
                        ViewData["ExcepMessage"] = "Employee Name does not exists. Cannot create Service Request.";                    
                        return View();
                    }
                    ViewData["IsVisible"] = "hidden";
                    Session["IsEmailValidated"] = true;
                    actionResult = base.View();
                }
                else if (submit.StartsWith("Create") || submit.StartsWith("Next"))
                {
                    //Session["requestID"] = null;
                    //FillDropDownListsControls();
                    //ViewData["reqEmailID"] = form[0];
                    //ViewData["empName"] = form[2];
                    //ViewData["ctrEmailID"] = form[3];
                    //ViewData["JobType"] = form[4];
                    //ViewData["ProjectCode"] = form[5];
                    //ViewData["ContractNo"] = form[6];
                    //ViewData["Quantity"] = form[7];
                    //ViewData["Unit"] = form[9];                 
                
                    //ViewData["Department"] = form[12];
                    //ViewData["DocRefNo"] = form[13];
                    //ViewData["Priority"] = form[14];
                    //ViewData["ProjectTitle"] = form[15];
                    //ViewData["DescripAreaVal"] = form[16];

                    //Session["reqEmailID"] = form[1];
                    //Session["empName"] = form[2];
                    //Session["ctrEmailID"] = form[3];
                    //Session["JobType"] = form[4];
                    //Session["ProjectCode"] = form[5];
                    //Session["ContractNo"] = form[6];
                    //Session["Quantity"] = form[7];
                    //Session["QuantityUnit"] = form[9];               
                    //Session["DepartmentID"] = form[12];
                    //Session["DocRefNo"] = form[13];
                    //Session["Priority"] = form[14];
                    //Session["ProjectTitle"] = form[15];
                    //Session["DescripAreaVal"] = form[16];

                    //ViewData["reqEmailID"] = form[0];
                    //ViewData["empName"] = form[1];
                    //ViewData["ctrEmailID"] = form[2];
                    //ViewData["JobType"] = form[3];
                    //ViewData["ProjectCode"] = form[4];
                    //ViewData["ContractNo"] = form[5];
                    //ViewData["Quantity"] = form[6];
                    //ViewData["Unit"] = form[7];
                
                    //ViewData["Department"] = form[10];
                    //ViewData["DocRefNo"] = form[11];
                    //ViewData["Priority"] = form[12];
                    //ViewData["ProjectTitle"] = form[13];
                    //ViewData["DescripAreaVal"] = form[14];

                    Session["reqEmailID"] = form[0];
                    Session["empName"] = form[1];
                    Session["JobType"] = form[2];
                    Session["ProjectCode"] = form[3];
                    Session["ContractNo"] = form[4];

                    if (form[5].ToString() == "Other")
                    {
                        Session["DepartmentID"] = "Other";
                        Session["OtherDept"] = form[6];
                    }
                    else
                    {
                        Session["DepartmentID"] = form[5];
                        Session["OtherDept"] = null;
                    }

                    Session["DocRefNo"] = form[8];
                    Session["ctrEmailID"] = form[10];
                    Session["Priority"] = form[11];
                    Session["Quantity"] = form[12];
                    Session["QuantityUnit"] = form[13];
                    Session["ProjectTitle"] = form[14];
                    Session["DescripAreaVal"] = form[15];

                
                    if (form[7].Split(',')[0] != "Other" && form[7].Split(',')[0] != "") //form[8] ContractorInfo
                    {
                        Session["Contractor"] = form[7].Split(',')[0];
                        Session["ContractorID"] = form[7].Split(',')[1];
                    }
                    else if (form[7].Split(',')[0] == "")
                    {                    
                        Session["Contractor"] = "";
                        Session["OtherContractor"] = "";
                        Session["ContractorID"] = "0";
                    }
                    else
                    {
                        Session["Contractor"] = "Other";
                        Session["OtherContractor"] = form[9];
                        Session["ContractorID"] = "0";
                    }

                    if (Session["files"] == null)
                    {
                        if (files[0] != null)
                        {
                            Session["files"] = files;
                        }
                    }
                    else
                    {
                        if (files[0] != null)
                        {
                            HttpPostedFileBase[] totFiles = new HttpPostedFileBase[(((HttpPostedFileBase[])Session["files"]).Length) + (files.Length)];                     
                            int i = 0;                        
                            foreach (HttpPostedFileBase file in (HttpPostedFileBase[])Session["files"])
                            {
                                totFiles[i] = file;
                                i++;
                            }
                            foreach (HttpPostedFileBase file in files)
                            {                                
                                totFiles[i] = file;
                                i++;
                            }                             
                            Session["files"] = totFiles;
                        }            
                    }

                    if (submit.StartsWith("Create"))
                    {
                        Session["ButtonName"] = "Create Polygon";
                        if (Session["IsEmailValidated"]== null)
                        {
                            ViewData["ExcepMessage"] = "EmailID has not been validated. First, Validate the email address and then click on Create Polygon button.";
                            FillDropDownListsControls();
                            actionResult = View();                            
                            return actionResult;
                        }
                        if (Session["IsRedirect"] == null)
                        {
                            var reqIDParam = new SqlParameter();
                            reqIDParam.ParameterName = "@p_request_ID";
                            reqIDParam.SqlDbType = SqlDbType.Int;
                            reqIDParam.Direction = ParameterDirection.Output;                            

                            var strReqIDParam = new SqlParameter();
                            strReqIDParam.ParameterName = "@p_req_ID";
                            strReqIDParam.SqlDbType = SqlDbType.VarChar;
                            strReqIDParam.Direction = ParameterDirection.Output;
                            strReqIDParam.Size = 10;

                            db.Database.ExecuteSqlCommand("GetSurveyRequestID @p_request_ID Out,@p_req_ID Out",
                            reqIDParam, strReqIDParam);                             

                            try
                            {
                                if (reqIDParam.Value.ToString() == "0")
                                {
                                    Session["requestID"] = strReqIDParam.Value.ToString();
                                }
                                else
                                {
                                    Session["requestID"] = reqIDParam.Value.ToString();
                                }
                                //Session["SuccessMessage"] = "Survey Request Created/Updated Successfully with number :" + Session["requestID"];
                                //ViewData["createSRDisabled"] = true;
                            }
                            catch (Exception ex)
                            {
                                //Session["SuccessMessage"] = null;
                                ViewData["ExcepMessage"] = "Error Occurred while retrieving the Survey Request ID";
                                //throw ex;
                            }
                        }
                    }
                    else
                    {
                        Session["ButtonName"] = "Next";
                        UploadFiles(false);
                    }                                
                
                    //else
                    //{

                    //    ViewData["Contractor"] = Session["Contractor"].ToString();
                    //}

                 
                    //ViewData["emailID"] = form[1];
                    //ViewData["JobType"] = form[2];
                    ////ViewData.SelectedItem = form[2];
                    //ViewData["ProjectCode"] = form[3];
                    //ViewData["ContractNo"] = form[4];
                    //ViewData["Quantity"] = form[5];
                    //ViewData["Unit"] = form[6];
                    //ViewData["Contractor"] = form[7];
                    //ViewData["Department"] = form[8];
                    //ViewData["DocRefNo"] = form[9];
                    //ViewData["Priority"] = form[10];
                    //ViewData["ProjectTitle"] = form[11];
                    //ViewData["DescripAreaVal"] = form[12];
                    //ViewData["submitSRDisabled"] = true;
                    actionResult = RedirectToAction("CreatePolygon", "ServiceRequest");
                }
                else if (submit.StartsWith("Follow"))
                {
                    Session["ButtonName"] = null;
                    Session["IsRedirect"] = null;
                    actionResult = RedirectToAction("SearchSurveyRqt", "ServiceRequest");
                }
                else if (submit.StartsWith("Cancel"))
                {
                    Session["ButtonName"] = null;
                    Session["IsRedirect"] = null;
                    Session["ctrEmailID"] = "set.k@gmail.com";
                    actionResult = RedirectToAction("ServiceRequest", "ServiceRequest");
                }
            }
            catch (Exception ex)
            {
                ViewData["ExcepMessage"] = "Unable to connect to the database.";
                actionResult = View();
            }
            return actionResult;
            //Session["emailID"] = form[1];
            //Session["JobType"] = form[2];
            ////Session.SelectedItem = form[2];
            //Session["ProjectCode"] = form[3];
            //Session["Quantity"] = form[4];
            //Session["Contractor"] = form[5];  
            //Session["DepartmentID"] = form[6];
            //Session["Priority"] = form[8];
            //Session["DocRefNo"] = form[7];
            //Session["ProjectTitle"] = form[9];
            //Session["DescripAreaVal"] = form[10];
            //return RedirectToAction("CreateSRWithMap", "ServiceRequest");

        }

        public ActionResult CreatePolygon()
        {
            ActionResult actionResult = null;
            //ViewData["msg"] = "SURVEY REQUEST";
            //Session["requestID"] = null;
            //FillDropDownListsControls();
            //ViewData["ProjectCode"] = "";
            //ViewData["ContractNo"] = "";
            //ViewData["Quantity"] = "";
            //ViewData["DocRefNo"] = "";
            //ViewData["ProjectTitle"] = "";
            SetSessionVariables();
            SetSurveyReqSecondHeading();
            if (Session["ButtonName"] != null)
            {
                if (Session["ButtonName"].ToString() == "Create Polygon")
                {
                    //ViewData["IsSubmitVisible"] = "visibility:visible";
                    //ViewData["IsActivatePolygonVisible"] = "visibility:visible";
                    //ViewData["IsClearGraphicsVisible"] = "visibility:visible";
                    //ViewData["IsDeactivateGraphicsVisible"] = "visibility:visible";
                    ViewData["IsHeaderVisible"] = "visibility:visible";
                    ViewData["CanCreatePolygon"] = "visibility:visible";
                    ViewData["WidgetLabelTitle"] = "FileUpload Or Coordinates:";
                    ViewData["WidgetDialogTitle"] = "Create Polygon(s)";
                    actionResult = View();
                }
                else
                {
                    //ViewData["IsSubmitVisible"] = "display:none";
                    //ViewData["IsActivatePolygonVisible"] = "display:none";
                    //ViewData["IsClearGraphicsVisible"] = "display:none";
                    //ViewData["IsDeactivateGraphicsVisible"] = "display:none";
                    ViewData["IsHeaderVisible"] = "display:none";
                    ViewData["CanCreatePolygon"] = "display:none";
                    ViewData["WidgetLabelTitle"] = "Coordinates:";
                    ViewData["WidgetDialogTitle"] = "View Polygon(s)";
                    actionResult = View();
                }
            }
            else
            {
                actionResult = RedirectToAction("SurveyRequest", "ServiceRequest");
            }
            //ViewData["submitSRDisabled"] = true;
            return actionResult;
            //Session["emailID"] = form[1];
            //Session["JobType"] = form[2];
            ////Session.SelectedItem = form[2];
            //Session["ProjectCode"] = form[3];
            //Session["Quantity"] = form[4];
            //Session["Contractor"] = form[5];
            //Session["DepartmentID"] = form[6];
            //Session["Priority"] = form[8];
            //Session["DocRefNo"] = form[7];
            //Session["ProjectTitle"] = form[9];
            //Session["DescripAreaVal"] = form[10];


        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        //[ValidateHeaderAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult CreatePolygon(FormCollection form, string submit, object[] objIds, string isCADFileUpload, string isCADRowDataUpdate)
        {
            //ViewData["msg"] = "SURVEY REQUEST";
            //Session["requestID"] = null;  
            //FillDropDownListsControls();
            Session["SuccessMessage"] = null;
            Session["ExcepMessage"] = null;
            ActionResult actionResult = null;

            if (submit == null)  //if (submit.StartsWith("Submit"))
            {
                if (isCADFileUpload == "1")
                {
                    if (System.Web.HttpContext.Current.Request.Files.AllKeys.Any())
                    {
                        //var file = System.Web.HttpContext.Current.Request.Files["file"];
                        HttpFileCollection hfc = System.Web.HttpContext.Current.Request.Files; //["file"];
                        for (int i = 0; i <= hfc.Count - 1; i++)
                        {
                            HttpPostedFile hpf = hfc[i];
                            if (hpf.ContentLength > 0)
                            {

                                try
                                {
                                    hpf.SaveAs(@"\\MV2GISS01\Survey\" + hpf.FileName.Substring(hpf.FileName.LastIndexOf('\\') + 1).Replace(hpf.FileName.Substring(hpf.FileName.LastIndexOf('\\') + 1).Split('.')[0],
                                       "SamplePolygon"));
                                }
                                catch (Exception ex)
                                {
                                    //Session["SuccessMessage"] = null;
                                    System.Web.HttpContext.Current.Session["ExcepMessage"] = "Error occurred while uploading the file";
                                    //throw ex;
                                }

                            }
                        }
                        
                    }

                    if (Session["ExcepMessage"] != null)
                    {
                        actionResult = base.Json(Session["ExcepMessage"].ToString(), JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        actionResult = base.Json(Session["requestID"].ToString(), JsonRequestBehavior.AllowGet);
                    }
                    SetSurveyReqSecondHeading();
                    return actionResult;                     
                }
                else
                {

                    //if (Session["IsSuccess"] == null)
                    //{
                    if (Session["reqEmailID"] != null)
                    {
                        string accountName = GetNameAndSetDeptFromAD(Session["reqEmailID"].ToString());
                        if (accountName.Equals("Error"))
                        {
                            @ViewData["ExcepMessage"] = "Error Occurred while retrieving the Requester Name";
                            //FillDropDownListsControls();
                            return actionResult = View();
                        }                         
                        //if (Session["requestID"] == null)
                        //{
                        //if (Session["DueDate"] != null)
                        //{
                        //short objCounter = 0;
                        string deptName = "";
                        string contractorName = "";
                        short determineOddIter = 1;
                        if (objIds != null)
                        {
                            if (objIds[0] != null)
                            {
                                if (objIds.Length != 0)
                                {
                                    try
                                    {                                         
                                        var reqIDParam = new SqlParameter();
                                        reqIDParam.ParameterName = "@reqID";
                                        reqIDParam.DbType = DbType.Int32;
                                        reqIDParam.Direction = ParameterDirection.InputOutput;
                                        reqIDParam.Value = Session["requestID"];
                                         
                                        db.Database.ExecuteSqlCommand("InsertOrUpdateInSurveyInfoSQLServer1 @reqID Out,@purpose,@priority,@dueDate, @projTitle, @descrip, @projCode, @wkQty, @managerComnts," + //@dueDate
                                        "@reqDept,@receiveDate, @status, @companyName, @companyId, @requesterID,@requesterName,@area,@areaUnit,@surveyLoc,@isWP,@zone,@actualCompDate,@refNo,@ctrEmailID,@units,@contractNo,"+
                                        "@requesterEmail",reqIDParam,
                                        new SqlParameter("purpose", Session["JobType"]), //JobType
                                        new SqlParameter("priority", Session["Priority"]), //priority
                                        new SqlParameter("dueDate", ""), //Convert.ToDateTime(Convert.ToDateTime(Session["DueDate"]).ToString("dd/MMM/yyyy") + " " + string.Format("{0:hh:mm:ss tt}", DateTime.Now))
                                        new SqlParameter("projTitle", Session["ProjectTitle"]), //ProjectTitle
                                        new SqlParameter("descrip", Session["DescripAreaVal"]),
                                        new SqlParameter("projCode", Session["ProjectCode"]),
                                        new SqlParameter("wkQty", Session["Quantity"]),
                                        new SqlParameter("managerComnts", DBNull.Value),
                                        new SqlParameter("reqDept", deptName),
                                        new SqlParameter("receiveDate", DateTime.Now.ToString("dd/MMM/yyyy")),
                                        new SqlParameter("status", "OPEN"),
                                        new SqlParameter("companyName", contractorName),
                                        new SqlParameter("companyId", Session["ContractorID"]),
                                        new SqlParameter("requesterID", Session["ContactID"]),
                                        new SqlParameter("requesterName", accountName),
                                        new SqlParameter("area", ""),
                                        new SqlParameter("areaUnit", ""),
                                        new SqlParameter("surveyLoc", ""),
                                        new SqlParameter("isWP", ""),
                                        new SqlParameter("zone", ""),
                                        new SqlParameter("actualCompDate", ""),
                                        new SqlParameter("refNo", Session["DocRefNo"]),
                                        new SqlParameter("ctrEmailID", Session["ctrEmailID"]),
                                        new SqlParameter("units", Session["QuantityUnit"]),
                                        new SqlParameter("contractNo", Session["CONTRACTNO"]),
                                        new SqlParameter("requesterEmail", Session["reqEmailID"]));

                                        Session["requestID"] = reqIDParam.Value;                                       
                                        Session["SuccessMessage"] = "Survey Request Created or Updated Successfully having number :" + Session["requestID"];                                        
                                        Session["IsSuccess"] = "1";
                                        Session["IsRedirect"] = "1";
                                    }
                                    catch (Exception ex)
                                    {
                                        Session["SuccessMessage"] = null;
                                        Session["ExcepMessage"] = "Error Occurred on first step while creating the Survey Request. Survey Request cannot be created. However, polygon may have been created successfully.";
                                        //throw ex;
                                    }

                                }

                                if(Session["ExcepMessage"] == null)
                                {
                                    for (short objIdx = 0; objIdx < objIds.Length; objIdx++)
                                    {

                                        OracleConnection con = new OracleConnection(System.Configuration.ConfigurationManager.ConnectionStrings["SurveyConnOracle"].ConnectionString);

                                        OracleCommand cmd = new OracleCommand();

                                        cmd.CommandType = CommandType.StoredProcedure;

                                        cmd.Connection = con;
                                        //if (submit.StartsWith("Submit"))
                                        //{ 
                                        cmd.CommandText = "InsertOrUpdateSurveyRequest1";   // SP                         
                                        cmd.Parameters.Add("p_request_ID", Session["requestID"].ToString());

                                        //cmd.Parameters.Add("p_request_ID", OracleDbType.Int32).Direction = ParameterDirection.InputOutput;
                                        //cmd.Parameters.Add(result); //"p_request_ID", surveyInfo[0].ToString());

                                        //Console.WriteLine(); 
                                        //cmd.Parameters.Add("p_request_ID", OracleDbType.Varchar2).Direction = ParameterDirection.InputOutput;
                                        cmd.Parameters.Add("p_object_ID", objIds[objIdx]);//objId

                                        if (determineOddIter % 2 == 1)
                                        {
                                            cmd.Parameters.Add("p_isSurveyor", "0");
                                        }
                                        else
                                        {
                                            cmd.Parameters.Add("p_isSurveyor", "1");
                                        }

                                        if (isCADRowDataUpdate == "1")
                                        {
                                            cmd.Parameters.Add("p_isUpload_File", "1");
                                        }
                                        else
                                        {
                                            cmd.Parameters.Add("p_isUpload_File", "0");
                                        }
                                        // cmd.Parameters.AddWithValue("@p_MaxID", SqlDbType.Int).Direction = ParameterDirection.Output;

                                        // cmd.Parameters.AddWithValue("@USER_ID", "Hatheem");

                                        try
                                        {
                                            con.Open();
                                            cmd.ExecuteNonQuery();
                                            determineOddIter++;
                                            con.Dispose();

                                            if (isFilesUploaded == false)
                                            {
                                                UploadFiles(true);
                                            }
                                            //ViewData["FileUploadMessage"] = "Files uploaded successfully";
                                            //ViewData["createSRDisabled"] = true;
                                        }
                                        catch (Exception ex)
                                        {
                                            Session["SuccessMessage"] = null;
                                            Session["ExcepMessage"] = "Error Occurred on second step while updating the details of Spatial data.";
                                            //throw ex;
                                        }
                                    }
                                }

                            }
                            else
                            {
                                Session["ExcepMessage"] = "Unable to insert or update the values of Requester because objectid is null. However, polygon may have been created successfully.";
                                actionResult = base.Json(Session["ExcepMessage"].ToString(), JsonRequestBehavior.AllowGet);
                                SetSurveyReqSecondHeading();
                                return actionResult;
                            } 
                        }
                        else
                        {
                            Session["ExcepMessage"] = "Unable to insert or update the values of Requester because objectid is null. However, polygon may have been created successfully.";
                            actionResult = base.Json(Session["ExcepMessage"].ToString(), JsonRequestBehavior.AllowGet);
                            SetSurveyReqSecondHeading();
                            return actionResult;
                        }
                        if (Session["SuccessMessage"] != null)
                        {
                            if (Session["ExcepMessage"] != null)
                            {
                                actionResult = base.Json(Session["SuccessMessage"].ToString() + " " + Session["ExcepMessage"].ToString(), JsonRequestBehavior.AllowGet);
                            }
                            else
                            {
                                actionResult = base.Json(Session["SuccessMessage"].ToString(), JsonRequestBehavior.AllowGet);
                            }
                        }
                        else
                        {
                            actionResult = base.Json(Session["ExcepMessage"].ToString(), JsonRequestBehavior.AllowGet);
                        }
                    }
                    else
                    {
                        actionResult = RedirectToAction("SurveyRequest", "ServiceRequest");
                    }
                }
                //}
                //else
                //{

                //    actionResult = base.Json("Graphic(s) Polygon(s) already submitted. Cannot resubmit the Graphic(s) Polygon(s) on second attempt. Create a new Survey Request.", JsonRequestBehavior.AllowGet);
                //    //actionResult = RedirectToAction("SurveyRequest", "ServiceRequest");
                //}
                //}
                //RedirectToAction("CreateSRWithMap");
                //FillDropDownListsControls();
                //if (Session["requestID"] != null)
                //{
                //    ViewData["createSRDisabled"] = false;
                //}
                //FillDropDownListsControls();
                ////SearchSurveyReq(submit, form[1]);
                //ViewData["emailID"] = form[1];
                //ViewData["JobType"] = form[2];
                ////ViewData.SelectedItem = form[2];
                //ViewData["ProjectCode"] = form[3];
                //ViewData["ContractNo"] = form[4];
                //ViewData["Quantity"] = form[5];
                //ViewData["Contractor"] = form[6];
                //ViewData["Department"] = form[7];
                //ViewData["DocRefNo"] = form[8];
                //ViewData["Priority"] = form[9];
                //ViewData["ProjectTitle"] = form[10];
                //ViewData["DescripAreaVal"] = form[11];
                
                //actionResult = View();
                //ViewData["Text"] = HttpUtility.HtmlDecode(hdnInnerHtml.Replace("\r", "").Replace("\n", ""));                
            }
            else if (submit.StartsWith("Search"))
            {
                actionResult = RedirectToAction("SearchSurveyRqt", "ServiceRequest");
            }             
            else if (submit.StartsWith("Previous"))
            {
                //if (Session["IsSuccess"] == null)
                //{                    
                    Session["IsRedirect"] = "1";
                //}
                //else
                //{
                //    Session["IsRedirect"] = null;
                //}
                actionResult = RedirectToAction("SurveyRequest", "ServiceRequest");
            }
            else if (submit.StartsWith("Follow"))
            {
                Session["ButtonName"] = null;
                Session["IsRedirect"] = null;
                actionResult = RedirectToAction("SearchSurveyRqt", "ServiceRequest");
            }
            else if (submit.StartsWith("Cancel"))
            {
                Session["ButtonName"] = null;
                Session["IsRedirect"] = null;
                actionResult = RedirectToAction("ServiceRequest", "ServiceRequest");
            }
            else if (submit.StartsWith("Create"))
            {
                Session["ButtonName"] = null;
                Session["IsRedirect"] = null;
                actionResult = RedirectToAction("SurveyRequest", "ServiceRequest");
            }
            
            //else if (submit.StartsWith("Submit"))
            //{
                //FillDropDownListsControls();
                //SearchSurveyReq(submit, form[1]);
                //ViewData["emailID"] = form[1];
                //ViewData["JobType"] = form[2];
                ////ViewData.SelectedItem = form[2];
                //ViewData["ProjectCode"] = form[3];
                //ViewData["ContractNo"] = form[4];
                //ViewData["Quantity"] = form[4];
                //ViewData["Contractor"] = form[5];
                //ViewData["Department"] = form[6];
                //ViewData["Priority"] = form[8];
                //ViewData["DocRefNo"] = form[7];
                //ViewData["ProjectTitle"] = form[10];
                //ViewData["DescripAreaVal"] = form[11];
            //    actionResult = View();
            //}
            SetSurveyReqSecondHeading();
            return actionResult;       

        }

        void SetSurveyReqSecondHeading()
        {
            if (Request.Cookies["culture"] != null)
            {
                if (Request.Cookies["culture"].Value == "en")
                {
                    ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
                    ViewData["msg"] = "SURVEY REQUEST";
                }
                else
                {
                    ViewData["firstHeading"] = EBDServiceRequest.ResourceAr.firstHeading;
                    ViewData["msg"] = "طلب مسح";
                }
            }
            else
            {
                ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
                ViewData["msg"] = "SURVEY REQUEST";
            }
        }

        [HttpPost]
        public ActionResult UploadCADFile() //HttpPostedFileBase file, HttpContext file
        {
            //HttpContext context = null;
            //context.Response.ContentType = "text/plain";
            //context.Response.Expires = -1;            
            //file.Response.ContentType = "text/plain";
            //file.Response.Expires = -1;
            //try
            //{

                //for (int i = 0; i < Request.Files.Count; i++)
                //{
                //    //var file = Request.Files[i];
                //    file.SaveAs(@"\\MV2GISS01\Survey\" + file.FileName.Substring(file.FileName.LastIndexOf('\\') + 1).Replace(file.FileName.Substring(file.FileName.LastIndexOf('\\') + 1).Split('.')[0],
                ////        "SamplePolygon"));
                //    // save file as required here...
                //}

                if (System.Web.HttpContext.Current.Request.Files.AllKeys.Any())
                {
                    //var file = System.Web.HttpContext.Current.Request.Files["file"];
                    HttpFileCollection hfc = System.Web.HttpContext.Current.Request.Files; //["file"];
                    for (int i = 0; i <= hfc.Count - 1; i++)
                    {
                        HttpPostedFile hpf = hfc[i];
                        if (hpf.ContentLength > 0)
                        {
          
                            try
                            {
                                hpf.SaveAs(@"\\MV2GISS01\Survey\" + hpf.FileName.Substring(hpf.FileName.LastIndexOf('\\') + 1).Replace(hpf.FileName.Substring(hpf.FileName.LastIndexOf('\\') + 1).Split('.')[0],
                                   "SamplePolygon"));
                            }
                            catch (Exception ex)
                            {
                                //Session["SuccessMessage"] = null;
                                System.Web.HttpContext.Current.Session["ExcepMessage"] = "Error occurred while uploading the file";
                                //throw ex;
                            }

                        }
                    }

                    try 
	                {
                        if (System.Web.HttpContext.Current.Session["ExcepMessage"] == null)
                        {
                            OracleConnection con = new OracleConnection(System.Configuration.ConfigurationManager.ConnectionStrings["SurveyConnOracle"].ConnectionString);

                            OracleCommand cmd = new OracleCommand();

                            cmd.CommandType = CommandType.StoredProcedure;

                            cmd.Connection = con;
                            //if (submit.StartsWith("Submit"))
                            //{ 
                            cmd.CommandText = "GetSurveyRequestID";   // SP                         

                            OracleParameter request_ID = new OracleParameter();
                            request_ID.ParameterName = "p_request_ID";
                            request_ID.OracleDbType = OracleDbType.Int32;
                            request_ID.Direction = ParameterDirection.Output;
                            cmd.Parameters.Add(request_ID);

                            OracleParameter p_req_ID = new OracleParameter();
                            p_req_ID.ParameterName = "p_req_ID";
                            p_req_ID.OracleDbType = OracleDbType.Varchar2;
                            p_req_ID.Direction = ParameterDirection.Output;
                            cmd.Parameters.Add(p_req_ID);
                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Dispose();
                            if (cmd.Parameters["p_request_ID"].Value.ToString() == "")
                            {
                                Session["requestID"] = cmd.Parameters["p_reqID"].Value.ToString();
                            }
                            else
                            {
                                Session["requestID"] = cmd.Parameters["p_request_ID"].Value.ToString();
                            }
                        }
                    }
                    catch (Exception)
                    {
                        ViewData["ExcepMessage"] = "Error Occurred while retrieving the Survey Request ID";
                        throw;
                    }           
                     
                }
                //HttpFileCollectionBase hfc = Request.Files;
                //for (int i = 0; i <= hfc.Count - 1; i++)
                //{
                //    HttpPostedFileBase hpf = hfc[i];
                //    if (hpf.ContentLength > 0)
                //    {
                        //filename = hpf.FileName;
                        //string folderName = string.Empty;
                        //if (Session["SectionID"].ToString().Equals("4"))
                        //{
                        //    folderName = newfolderNme;                       //  ConfigurationManager.AppSettings["SurveyfolderName"].ToString();
                        //    filePath = Path.Combine(folderName, filename);
                        //}
                        //else
                        //{
                        //    folderName = ConfigurationManager.AppSettings["NonEBDfolderName"].ToString();
                        //    filePath = Path.Combine(folderName, filename);
                        //}
                        //string filePath = @"\\MV2GISS01\Survey\" + hpf.FileName;
                        //hpf.SaveAs(filePath);

                //        hpf.SaveAs(@"\\MV2GISS01\Survey\" + hpf.FileName.Substring(hpf.FileName.LastIndexOf('\\') + 1).Replace(hpf.FileName.Substring(hpf.FileName.LastIndexOf('\\') + 1).Split('.')[0],
                //            "SamplePolygon"));
                //    }
                //}
            //try
            //{


                //HttpPostedFileBase[] files = (HttpPostedFileBase[])Session["files"];
                //if (files[0] != null)
                //{
                //    foreach (HttpPostedFileBase file in files)
                //    {
                //        //Checking file is available to save.  
                //        if (file != null)
                //        {

                            //if (!System.IO.Directory.Exists(@"\\MV2GISS01\Survey\"))
                            //    System.IO.Directory.CreateDirectory(filePath);

                            //if (Request.UserAgent.IndexOf("MSIE") == -1)
                            //{
                                // The browser is Microsoft Internet Explorer Version 6.0.
                //HttpFileCollection hfc = context.Request.Files;
                //for (int i = 0; i < files.Count(); i++)
                //{
                //    HttpPostedFile hpf = hfc[i];
                //    if (hpf.ContentLength > 0)
                //    {
                //        file.SaveAs(@"\\MV2GISS01\Survey\" + file.FileName.Substring(file.FileName.LastIndexOf('\\') + 1).Replace(file.FileName.Substring(file.FileName.LastIndexOf('\\') + 1).Split('.')[0],
                //        "SamplePolygon")); //file.FileName.Substring(file.FileName.LastIndexOf("\\") + 1)
                //    }
                //}
                            //}
                            //else
                            //{
                            //    file.SaveAs(@"\\MV2GISS01\Survey\" + Session["requestID"] + "_" + file.FileName);
                            //}
                    //    }
                    //}

                    //if (isCreate)
                    //{
                    //    Session["SuccessMessage"] = Session["SuccessMessage"] + ". Files uploaded successfully";
                    //}
                    //else
                    //{
                    //    Session["SuccessMessage"] = "Files uploaded successfully";
                    //}
                //}
                //HttpFileCollection hfc = context.Request.Files;
                //for (int i = 0; i < files.Count(); i++)
                //{
                //    HttpPostedFile hpf = hfc[i];
                //    if (hpf.ContentLength > 0)
                //    {
                //        //filename = hpf.FileName;
                //        //string folderName = string.Empty;
                //        //if (Session["SectionID"].ToString().Equals("4"))
                //        //{
                //        //    folderName = newfolderNme;                       //  ConfigurationManager.AppSettings["SurveyfolderName"].ToString();
                //        //    filePath = Path.Combine(folderName, filename);
                //        //}
                //        //else
                //        //{
                //        //    folderName = ConfigurationManager.AppSettings["NonEBDfolderName"].ToString();
                //        //    filePath = Path.Combine(folderName, filename);
                //        //}
                //        //string filePath = @"\\MV2GISS01\Survey\" + hpf.FileName;
                //        //hpf.SaveAs(filePath);

                //        hpf.SaveAs(@"\\MV2GISS01\Survey\" + hpf.FileName.Substring(hpf.FileName.LastIndexOf('\\') + 1).Replace(hpf.FileName.Substring(hpf.FileName.LastIndexOf('\\') + 1).Split('.')[0],
                //            "SamplePolygon"));
                //    }
                //}
            //}
            //catch (Exception ex)
            //{
            //    Session["ExcepMessage"] = "Error occurred while uploading the file";
            //    //context.Response.Write("Error occurred while uploading the file");
            //}
            return View();
        }

        bool isFilesUploaded = false;         

        private void UploadFiles(bool isCreate)
        {
            string filePath = null;
            try
            {
                filePath = ConfigurationManager.AppSettings["SurveyFolderPath"].ToString();
                HttpPostedFileBase[] files = (HttpPostedFileBase[])Session["files"];
                if (files != null)
                {
                    if (files[0] != null)
                    {
                        if (!System.IO.Directory.Exists(filePath + "\\Year_" + DateTime.Now.Year))
                        {
                            System.IO.Directory.CreateDirectory(filePath + "\\Year_" + DateTime.Now.Year);
                        }
                        filePath = filePath + "\\Year_" + DateTime.Now.Year + "\\" + Session["requestID"];
                        if (!System.IO.Directory.Exists(filePath))
                        {
                            System.IO.Directory.CreateDirectory(filePath);
                        }
                        if (!System.IO.Directory.Exists(filePath + "\\ApplicantData"))
                        {
                            System.IO.Directory.CreateDirectory(filePath + "\\ApplicantData");
                        }
                        if (!System.IO.Directory.Exists(filePath + "\\Final"))
                        {
                            System.IO.Directory.CreateDirectory(filePath + "\\Final");
                        }
                        if (!System.IO.Directory.Exists(filePath + "\\Working"))
                        {
                            System.IO.Directory.CreateDirectory(filePath + "\\Working");
                        }
                        foreach (HttpPostedFileBase file in files)
                        {
                            //Checking file is available to save.  
                            if (file != null)
                            {
                                if (Request.UserAgent.IndexOf("MSIE") == -1)
                                {
                                    // The browser is Microsoft Internet Explorer Version 6.0.
                                    file.SaveAs(filePath + "\\ApplicantData\\" + Session["requestID"] + "_" + file.FileName.Substring(file.FileName.LastIndexOf("\\") + 1));
                                }
                                else
                                {
                                    file.SaveAs(filePath + "\\ApplicantData\\" + Session["requestID"] + "_" + file.FileName);
                                }
                            }
                        }
                        if (isCreate)
                        {
                            isFilesUploaded = true;
                            Session["SuccessMessage"] = Session["SuccessMessage"].ToString() + ". Files uploaded successfully";
                        }
                        //else
                        //{
                        //    Session["SuccessMessage"] = "Files uploaded successfully";
                        //}                        
                    }
                }
            }
            catch (Exception ex)
            {
                Session["ExcepMessage"] = ex.Message.Replace("'","").Replace("\"",""); // "Error Occurred while uploading the files";
            }

        }

        

        [HttpPost]
        //[ValidateAntiForgeryToken]
        [ValidateHeaderAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult CreateSRWithMap(FormCollection form, string submit, object[] objIds, string[] fieldVals)
        {
            //Session["ArcGISTiledMapServiceLayerUrl"] = ConfigurationManager.AppSettings["ArcGISTiledMapServiceUrl"].ToString();
            //Session["CadastralPlotsServiceUrl"] = ConfigurationManager.AppSettings["CadastralPlotsServiceUrl"].ToString();
            //Session["Control95ServiceUrl"] = ConfigurationManager.AppSettings["Control95ServiceUrl"].ToString();
            //Session["ImageServiceUrl"] = ConfigurationManager.AppSettings["ImageServiceUrl"].ToString();
            //Session["PolicyPlanPlotServiceUrl"] = ConfigurationManager.AppSettings["PolicyPlanPlotServiceUrl"].ToString();
            //Session["FeatureLayerUrl"] = ConfigurationManager.AppSettings["FeatureLayerUrl"].ToString();
            //Session["GeoProcessorUrl"] = ConfigurationManager.AppSettings["GeoProcessorUrl"].ToString();
            //ViewData["msg"] = "SURVEY REQUEST";
            //FillJobTypes();
            //FillContractors();
            //FillDeptOraDB();
            //FillGrades();
            //ViewData["createSRDisabled"] = false;
            //this.SetDisbaledProperties(false);
            //EBDServiceRequests ebdServiceRequests = new EBDServiceRequests();
            //ebdServiceRequests.serviceRequestDate = new DateTime?(DateTime.Now);
            //this.FillDepartment();
            //this.FillSections();
            //this.FillServiceTypes();
            //this.FillAndSetServiceTypeSubCategory(1, 0, false); submit.StartsWith("Create") || 
            ActionResult actionResult = null;

            if (submit==null)  //if (submit.StartsWith("Submit"))
            {
                //if (Session["requestID"] == null)
                //{
                //if (Session["DueDate"] != null)
                //{
                //short objCounter = 0;
                if (objIds != null)
                {
                    if (objIds[0].ToString() != "")
                    {
                    //for (short objIdx = 0; objIdx < form[12].Split(',').Length; objIdx++)
                        for (short objIdx = 0; objIdx < objIds.Length; objIdx++)
                        {

                            OracleConnection con = new OracleConnection(System.Configuration.ConfigurationManager.ConnectionStrings["SurveyConnOracle"].ConnectionString);

                            OracleCommand cmd = new OracleCommand();

                            cmd.CommandType = CommandType.StoredProcedure;

                            cmd.Connection = con;
                            //if (submit.StartsWith("Submit"))
                            //{ 
                            cmd.CommandText = "InsertAndUpdateSurveyRequest";   // SP                         

                            OracleParameter result = new OracleParameter();
                            result.ParameterName = "p_request_ID";
                            result.OracleDbType = OracleDbType.Int32;
                            result.Direction = ParameterDirection.Output;
                            //result.Value = " ";// objIds[objIdx];
                            cmd.Parameters.Add(result);
                            //cmd.Parameters.Add("p_request_ID", OracleDbType.Int32).Direction = ParameterDirection.InputOutput;
                            //cmd.Parameters.Add(result); //"p_request_ID", surveyInfo[0].ToString());

                            //Console.WriteLine(); 
                            //cmd.Parameters.Add("p_request_ID", OracleDbType.Varchar2).Direction = ParameterDirection.InputOutput;
                            cmd.Parameters.Add("p_object_ID", objIds[objIdx]);//objId
                            cmd.Parameters.Add("p_REQUESTER_MAIL", fieldVals[0]);//EmailID
                            //DateTime dt = Convert.ToDateTime("15/Jan/2019 18:33:22 PM");
                            //string time = new DateTime(dt.Ticks).ToString("hh:mm:ss"); 
                            cmd.Parameters.Add("p_REQUEST_TIME", DateTime.Now.ToString("dd/MM/yyyy") + " " + DateTime.Now.TimeOfDay.ToString().Split('.')[0]);

                            // cmd.Parameters.Add("p_REQUEST_TIME", _currentDate);
                            string accountName = GetNameAndSetDeptFromAD(fieldVals[0]);
                            if (accountName.Equals("Error"))
                            {
                                @ViewData["ExcepMessage"] = "Error Occurred while retrieving the Requester Name";
                                FillDropDownListsControls();
                                return actionResult = View();
                            }
                            else
                            {
                                cmd.Parameters.Add("p_requesterName", accountName); //Session["UserDisplayName"].ToString()
                            }

                            cmd.Parameters.Add("p_STATUS_ORG", "");

                            cmd.Parameters.Add("p_DESCRIPTION", fieldVals[1]); //Description

                            cmd.Parameters.Add("p_ASSIGNED_TO", "");

                            //cmd.Parameters.Add("p_EXPECTED_COMP_DATE", " "); //DueDate

                            //cmd.Parameters.Add("p_ACTUAL_COMP_DATE", " ");

                            cmd.Parameters.Add("p_PRIORITY", fieldVals[2]); //Grades

                            cmd.Parameters.Add("p_PURPOSE", fieldVals[3]); //JobType

                            cmd.Parameters.Add("p_MANAGER_COMMENTS", "");

                            cmd.Parameters.Add("p_REQUESTER_ID", "");

                            cmd.Parameters.Add("p_STATUS", "OPEN");

                            cmd.Parameters.Add("p_PROJECT_NO", fieldVals[4]); //ProjectCode

                            //cmd.Parameters.Add("p_PROJECT_NO", form[3]); //ProjectCode


                            cmd.Parameters.Add("p_PROJECT_NAME", fieldVals[5]); //ProjectTitle
                            //ViewData["ProjectTitle"] = true;
                            cmd.Parameters.Add("p_STATUS_ID", "1");

                            cmd.Parameters.Add("p_WORKQTY", fieldVals[6]); //Quantity

                            cmd.Parameters.Add("p_CONTRACTOR_NAME", fieldVals[7]); //Contractors

                            cmd.Parameters.Add("p_CONTRACTORID", fieldVals[8]);

                            //cmd.Parameters.AddWithValue("@REQUESTER_MAIL", "svadakpuram@ashghal.gov.qa");

                            cmd.Parameters.Add("p_REQUESTER_DEPT", fieldVals[9]); //Departments

                            cmd.Parameters.Add("p_REFNO", fieldVals[10]); //DocRefNo


                            //cmd.Parameters.Add("p_area", "");
                            //cmd.Parameters.Add("p_areaUnit", "0");
                            //cmd.Parameters.Add("p_surveyLoc", "");
                            //cmd.Parameters.Add("p_isWP", "");
                            //cmd.Parameters.Add("p_zone", "");

                            // cmd.Parameters.AddWithValue("@p_MaxID", SqlDbType.Int).Direction = ParameterDirection.Output;

                            // cmd.Parameters.AddWithValue("@USER_ID", "Hatheem");

                            try
                            {
                                con.Open();
                                cmd.ExecuteNonQuery();
                                con.Dispose();
                                Session["requestID"] = cmd.Parameters["p_request_ID"].Value.ToString();
                                ViewData["Message"] = "Survey Request Created Successfully having number :" + Session["requestID"] + ". Now create Survey Area as a polygon on the map.";
                                ViewData["createSRDisabled"] = true;
                            }
                            catch (Exception ex)
                            {
                                ViewData["Message"] = null;
                                ViewData["ExcepMessage"] = "Error Occurred on first step while creating the Survey Request. Survey Request cannot be created.";
                                //throw ex;
                            }
                            try
                            {
                                if (ViewData["Message"] != null)
                                {
                                    //string[] surveyReqInfo = new string[20];
                                    //surveyReqInfo[0] = Session["requestID"].ToString();
                                    //surveyReqInfo[1] = form[2]; //JobType
                                    //surveyReqInfo[2] = form[9]; //Priority
                                    //surveyReqInfo[3] = Convert.ToDateTime(Session["DueDate"]).ToString("dd/MMM/yyyy"); // DueDate
                                    //surveyReqInfo[4] = form[11]; //ProjectTitle
                                    //surveyReqInfo[5] = " ";
                                    //surveyReqInfo[6] = form[3]; //ProjectCode
                                    //surveyReqInfo[7] = form[4]; //Quantity
                                    //surveyReqInfo[8] = " ";
                                    //surveyReqInfo[9] = form[7]; //Departments
                                    //surveyReqInfo[10] = DateTime.Now.ToString("dd/MMM/yyyy"); // +" " + DateTime.Now.ToShortTimeString();
                                    //surveyReqInfo[11] = "OPEN";
                                    //surveyReqInfo[12] = form[6].Split(',')[0]; //Contractors
                                    //surveyReqInfo[13] = form[6].Split(',')[1];
                                    //surveyReqInfo[14] = accountName;
                                    //surveyReqInfo[15] = " "; //txtArea.Text
                                    //surveyReqInfo[16] = " "; //ddlUnits.SelectedIndex.ToString()
                                    //surveyReqInfo[17] = " "; //ddlSurveyLoc.SelectedItem.Text
                                    //surveyReqInfo[18] = " "; //ddlWP.SelectedValue
                                    ////if (txtSurveyZone.Text.Trim().Equals(""))
                                    ////{
                                    //surveyReqInfo[19] = " "; //txtSurveyZone.Text

                                    db.Database.ExecuteSqlCommand("InsertOrUpdateInSurveyInfoSQLServer @reqID,@purpose,@priority,@dueDate, @projTitle, @descrip, @projCode, @wkQty, @managerComnts," + //@dueDate
                                            "@reqDept, @receiveDate, @status, @companyName, @companyId, @requesterName,@area,@areaUnit,@surveyLoc,@isWP,@zone,@actualCompDate,@refNo",
                                            new SqlParameter("reqID", Session["requestID"].ToString()),
                                            new SqlParameter("purpose", fieldVals[3]), //JobType
                                            new SqlParameter("priority", fieldVals[2]), //priority
                                            new SqlParameter("dueDate", ""), //Convert.ToDateTime(Convert.ToDateTime(Session["DueDate"]).ToString("dd/MMM/yyyy") + " " + string.Format("{0:hh:mm:ss tt}", DateTime.Now))
                                            new SqlParameter("projTitle", fieldVals[5]), //ProjectTitle
                                            new SqlParameter("descrip", fieldVals[1]),
                                            new SqlParameter("projCode", fieldVals[4]),
                                            new SqlParameter("wkQty", fieldVals[6]),
                                            new SqlParameter("managerComnts", DBNull.Value),
                                            new SqlParameter("reqDept", fieldVals[9]),
                                            new SqlParameter("receiveDate", DateTime.Now.ToString("dd/MMM/yyyy")),
                                            new SqlParameter("status", "OPEN"),
                                            new SqlParameter("companyName", fieldVals[7]),
                                            new SqlParameter("companyId", fieldVals[8]),
                                            new SqlParameter("requesterName", accountName),
                                            new SqlParameter("area", ""),
                                            new SqlParameter("areaUnit", ""),
                                            new SqlParameter("surveyLoc", ""),
                                            new SqlParameter("isWP", ""),
                                            new SqlParameter("zone", ""),
                                            new SqlParameter("actualCompDate",""),
                                            new SqlParameter("refNo", fieldVals[10]));
                                }
                            }
                            catch (Exception ex)
                            {
                                ViewData["ExcepMessage"] = "Error Occurred on second step while creating the Survey Request. Although, Survey Request has been successfully created on first step.";
                            }
                            finally
                            {
                                con.Close();
                            }
                        }
                        //}
                    }
                }
                //}
                //RedirectToAction("CreateSRWithMap");
                //FillDropDownListsControls();
                //if (Session["requestID"] != null)
                //{
                //    ViewData["createSRDisabled"] = false;
                //}
                FillDropDownListsControls();
                //SearchSurveyReq(submit, form[1]);
                ViewData["emailID"] = form[1];
                ViewData["JobType"] = form[2];
                //ViewData.SelectedItem = form[2];
                ViewData["ProjectCode"] = form[3];
                ViewData["ContractNo"] = form[4];
                ViewData["Quantity"] = form[5];
                ViewData["Contractor"] = form[6];
                ViewData["Department"] = form[7];
                ViewData["DocRefNo"] = form[8];
                ViewData["Priority"] = form[9];                
                ViewData["ProjectTitle"] = form[10];
                ViewData["DescripAreaVal"] = form[11];
                actionResult = View();
                //actionResult = View();
                //ViewData["Text"] = HttpUtility.HtmlDecode(hdnInnerHtml.Replace("\r", "").Replace("\n", ""));                
            }
            else if (submit.StartsWith("Search"))
            {
                actionResult = RedirectToAction("SearchSurveyRqt", "ServiceRequest");
            }
            else if (submit.StartsWith("Cancel"))
            {
                actionResult = RedirectToAction("ServiceRequest", "ServiceRequest");
            }
            else if (submit.StartsWith("Submit"))
            {

                for (short objIdx = 0; objIdx < objIds.Length; objIdx++)
                {

                    OracleConnection con = new OracleConnection(System.Configuration.ConfigurationManager.ConnectionStrings["SurveyConnOracle"].ConnectionString);

                    OracleCommand cmd = new OracleCommand();

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Connection = con;
                    //if (submit.StartsWith("Submit"))
                    //{ 
                    cmd.CommandText = "InsertAndUpdateSurveyRequest";   // SP                         

                    OracleParameter result = new OracleParameter();
                    result.ParameterName = "p_request_ID";
                    result.OracleDbType = OracleDbType.Int32;
                    result.Direction = ParameterDirection.Output;
                    //result.Value = " ";// objIds[objIdx];
                    cmd.Parameters.Add(result);
                    //cmd.Parameters.Add("p_request_ID", OracleDbType.Int32).Direction = ParameterDirection.InputOutput;
                    //cmd.Parameters.Add(result); //"p_request_ID", surveyInfo[0].ToString());

                    //Console.WriteLine(); 
                    //cmd.Parameters.Add("p_request_ID", OracleDbType.Varchar2).Direction = ParameterDirection.InputOutput;
                    cmd.Parameters.Add("p_object_ID", objIds[objIdx]);//objId
                    cmd.Parameters.Add("p_REQUESTER_MAIL", ViewData["reqEmailID"]);//EmailID
                    //DateTime dt = Convert.ToDateTime("15/Jan/2019 18:33:22 PM");
                    //string time = new DateTime(dt.Ticks).ToString("hh:mm:ss"); 
                    cmd.Parameters.Add("p_REQUEST_TIME", DateTime.Now.ToString("dd/MM/yyyy") + " " + DateTime.Now.TimeOfDay.ToString().Split('.')[0]);

                    // cmd.Parameters.Add("p_REQUEST_TIME", _currentDate);
                    string accountName = GetNameAndSetDeptFromAD(fieldVals[0]);
                    if (accountName.Equals("Error"))
                    {
                        @ViewData["ExcepMessage"] = "Error Occurred while retrieving the Requester Name";
                        FillDropDownListsControls();
                        return actionResult = View();
                    }
                    else
                    {
                        cmd.Parameters.Add("p_requesterName", accountName); //Session["UserDisplayName"].ToString()
                    }

                    cmd.Parameters.Add("p_STATUS_ORG", "");

                    cmd.Parameters.Add("p_DESCRIPTION", fieldVals[1]); //Description

                    cmd.Parameters.Add("p_ASSIGNED_TO", "");

                    //cmd.Parameters.Add("p_EXPECTED_COMP_DATE", " "); //DueDate

                    //cmd.Parameters.Add("p_ACTUAL_COMP_DATE", " ");

                    cmd.Parameters.Add("p_PRIORITY", fieldVals[2]); //Grades

                    cmd.Parameters.Add("p_PURPOSE", fieldVals[3]); //JobType

                    cmd.Parameters.Add("p_MANAGER_COMMENTS", "");

                    cmd.Parameters.Add("p_REQUESTER_ID", "");

                    cmd.Parameters.Add("p_STATUS", "OPEN");

                    cmd.Parameters.Add("p_PROJECT_NO", fieldVals[4]); //ProjectCode

                    //cmd.Parameters.Add("p_PROJECT_NO", form[3]); //ProjectCode


                    cmd.Parameters.Add("p_PROJECT_NAME", fieldVals[5]); //ProjectTitle
                    //ViewData["ProjectTitle"] = true;
                    cmd.Parameters.Add("p_STATUS_ID", "1");

                    cmd.Parameters.Add("p_WORKQTY", fieldVals[6]); //Quantity

                    cmd.Parameters.Add("p_CONTRACTOR_NAME", fieldVals[7]); //Contractors

                    cmd.Parameters.Add("p_CONTRACTORID", fieldVals[8]);

                    //cmd.Parameters.AddWithValue("@REQUESTER_MAIL", "svadakpuram@ashghal.gov.qa");

                    cmd.Parameters.Add("p_REQUESTER_DEPT", fieldVals[9]); //Departments

                    cmd.Parameters.Add("p_REFNO", fieldVals[10]); //DocRefNo


                    //cmd.Parameters.Add("p_area", "");
                    //cmd.Parameters.Add("p_areaUnit", "0");
                    //cmd.Parameters.Add("p_surveyLoc", "");
                    //cmd.Parameters.Add("p_isWP", "");
                    //cmd.Parameters.Add("p_zone", "");

                    // cmd.Parameters.AddWithValue("@p_MaxID", SqlDbType.Int).Direction = ParameterDirection.Output;

                    // cmd.Parameters.AddWithValue("@USER_ID", "Hatheem");

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Dispose();
                        Session["requestID"] = cmd.Parameters["p_request_ID"].Value.ToString();
                        ViewData["Message"] = "Survey Request Created Successfully having number :" + Session["requestID"] + ". Now create Survey Area as a polygon on the map.";
                        ViewData["createSRDisabled"] = true;
                    }
                    catch (Exception ex)
                    {
                        ViewData["Message"] = null;
                        ViewData["ExcepMessage"] = "Error Occurred on first step while creating the Survey Request. Survey Request cannot be created.";
                        //throw ex;
                    }
                    try
                    {
                        if (ViewData["Message"] != null)
                        {
                            //string[] surveyReqInfo = new string[20];
                            //surveyReqInfo[0] = Session["requestID"].ToString();
                            //surveyReqInfo[1] = form[2]; //JobType
                            //surveyReqInfo[2] = form[9]; //Priority
                            //surveyReqInfo[3] = Convert.ToDateTime(Session["DueDate"]).ToString("dd/MMM/yyyy"); // DueDate
                            //surveyReqInfo[4] = form[11]; //ProjectTitle
                            //surveyReqInfo[5] = " ";
                            //surveyReqInfo[6] = form[3]; //ProjectCode
                            //surveyReqInfo[7] = form[4]; //Quantity
                            //surveyReqInfo[8] = " ";
                            //surveyReqInfo[9] = form[7]; //Departments
                            //surveyReqInfo[10] = DateTime.Now.ToString("dd/MMM/yyyy"); // +" " + DateTime.Now.ToShortTimeString();
                            //surveyReqInfo[11] = "OPEN";
                            //surveyReqInfo[12] = form[6].Split(',')[0]; //Contractors
                            //surveyReqInfo[13] = form[6].Split(',')[1];
                            //surveyReqInfo[14] = accountName;
                            //surveyReqInfo[15] = " "; //txtArea.Text
                            //surveyReqInfo[16] = " "; //ddlUnits.SelectedIndex.ToString()
                            //surveyReqInfo[17] = " "; //ddlSurveyLoc.SelectedItem.Text
                            //surveyReqInfo[18] = " "; //ddlWP.SelectedValue
                            ////if (txtSurveyZone.Text.Trim().Equals(""))
                            ////{
                            //surveyReqInfo[19] = " "; //txtSurveyZone.Text

                            db.Database.ExecuteSqlCommand("InsertOrUpdateInSurveyInfoSQLServer @reqID,@purpose,@priority,@dueDate, @projTitle, @descrip, @projCode, @wkQty, @managerComnts," + //@dueDate
                                    "@reqDept, @receiveDate, @status, @companyName, @companyId, @requesterName,@area,@areaUnit,@surveyLoc,@isWP,@zone,@actualCompDate,@refNo",
                                    new SqlParameter("reqID", Session["requestID"].ToString()),
                                    new SqlParameter("purpose", fieldVals[3]), //JobType
                                    new SqlParameter("priority", fieldVals[2]), //priority
                                    new SqlParameter("dueDate", ""), //Convert.ToDateTime(Convert.ToDateTime(Session["DueDate"]).ToString("dd/MMM/yyyy") + " " + string.Format("{0:hh:mm:ss tt}", DateTime.Now))
                                    new SqlParameter("projTitle", fieldVals[5]), //ProjectTitle
                                    new SqlParameter("descrip", fieldVals[1]),
                                    new SqlParameter("projCode", fieldVals[4]),
                                    new SqlParameter("wkQty", fieldVals[6]),
                                    new SqlParameter("managerComnts", DBNull.Value),
                                    new SqlParameter("reqDept", fieldVals[9]),
                                    new SqlParameter("receiveDate", DateTime.Now.ToString("dd/MMM/yyyy")),
                                    new SqlParameter("status", "OPEN"),
                                    new SqlParameter("companyName", fieldVals[7]),
                                    new SqlParameter("companyId", fieldVals[8]),
                                    new SqlParameter("requesterName", accountName),
                                    new SqlParameter("area", ""),
                                    new SqlParameter("areaUnit", ""),
                                    new SqlParameter("surveyLoc", ""),
                                    new SqlParameter("isWP", ""),
                                    new SqlParameter("zone", ""),
                                    new SqlParameter("actualCompDate", ""),
                                    new SqlParameter("refNo", fieldVals[10]));
                        }
                    }
                    catch (Exception ex)
                    {
                        ViewData["ExcepMessage"] = "Error Occurred on second step while creating the Survey Request. Although, Survey Request has been successfully created on first step.";
                    }
                    finally
                    {
                        con.Close();
                    }
                }
                //FillDropDownListsControls();
                //SearchSurveyReq(submit, form[1]);
                //ViewData["emailID"] = form[1];
                //ViewData["JobType"] = form[2];
                ////ViewData.SelectedItem = form[2];
                //ViewData["ProjectCode"] = form[3];
                //ViewData["ContractNo"] = form[4];
                //ViewData["Quantity"] = form[4];
                //ViewData["Contractor"] = form[5];
                //ViewData["Department"] = form[6];
                //ViewData["Priority"] = form[8];
                //ViewData["DocRefNo"] = form[7];
                //ViewData["ProjectTitle"] = form[10];
                //ViewData["DescripAreaVal"] = form[11];
                actionResult = View();
            }
            SetSurveyReqSecondHeading();
            return actionResult; //"<script>var settings = { map: map,layerInfos: featureLayerInfos }; var params = {settings: settings};" +
            //"editorWidget = new Editor(params, 'editorDiv');editorWidget.startup();map.enableSnapping();</script>");
        }

        //// POST: /ServiceRequest/CreateSR
        //// To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        //// more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //[ValidateInput(false)]
        //public ActionResult CreateSRWithMap(FormCollection form, string submit, string[] objIds)
        //{            
        //    //Session["ArcGISTiledMapServiceLayerUrl"] = ConfigurationManager.AppSettings["ArcGISTiledMapServiceUrl"].ToString();
        //    //Session["CadastralPlotsServiceUrl"] = ConfigurationManager.AppSettings["CadastralPlotsServiceUrl"].ToString();
        //    //Session["Control95ServiceUrl"] = ConfigurationManager.AppSettings["Control95ServiceUrl"].ToString();
        //    //Session["ImageServiceUrl"] = ConfigurationManager.AppSettings["ImageServiceUrl"].ToString();
        //    //Session["PolicyPlanPlotServiceUrl"] = ConfigurationManager.AppSettings["PolicyPlanPlotServiceUrl"].ToString();
        //    //Session["FeatureLayerUrl"] = ConfigurationManager.AppSettings["FeatureLayerUrl"].ToString();
        //    //Session["GeoProcessorUrl"] = ConfigurationManager.AppSettings["GeoProcessorUrl"].ToString();
        //    //ViewData["msg"] = "SURVEY REQUEST";
        //    //FillJobTypes();
        //    //FillContractors();
        //    //FillDeptOraDB();
        //    //FillGrades();
        //    //ViewData["createSRDisabled"] = false;
        //    //this.SetDisbaledProperties(false);
        //    //EBDServiceRequests ebdServiceRequests = new EBDServiceRequests();
        //    //ebdServiceRequests.serviceRequestDate = new DateTime?(DateTime.Now);
        //    //this.FillDepartment();
        //    //this.FillSections();
        //    //this.FillServiceTypes();
        //    //this.FillAndSetServiceTypeSubCategory(1, 0, false); submit.StartsWith("Create") || 
        //    ActionResult actionResult = null;
        //    if (submit.StartsWith("Submit"))
        //    {
        //        if (Session["requestID"] == null)
        //        {
        //            //if (Session["DueDate"] != null)
        //            //{
        //            //short objCounter = 0;
        //            for (short objIdx = 0; objIdx < objIds.Length; objIdx++)
        //            {

        //                OracleConnection con = new OracleConnection(System.Configuration.ConfigurationManager.ConnectionStrings["SurveyConnOracle"].ConnectionString);

        //                OracleCommand cmd = new OracleCommand();

        //                cmd.CommandType = CommandType.StoredProcedure;

        //                cmd.Connection = con;
        //                //if (submit.StartsWith("Submit"))
        //                //{ 
        //                cmd.CommandText = "InsertAndUpdateSurveyRequest";   // SP                         

        //                OracleParameter result = new OracleParameter();
        //                result.ParameterName = "p_request_ID";
        //                result.OracleDbType = OracleDbType.Varchar2;
        //                result.Direction = ParameterDirection.Output;
        //                //result.Value = objIds[objIdx];
        //                cmd.Parameters.Add(result);
        //                //cmd.Parameters.Add("p_request_ID", OracleDbType.Int32).Direction = ParameterDirection.InputOutput;
        //                //cmd.Parameters.Add(result); //"p_request_ID", surveyInfo[0].ToString());

        //                //Console.WriteLine(); 
        //                //cmd.Parameters.Add("p_request_ID", OracleDbType.Varchar2).Direction = ParameterDirection.InputOutput;
        //                cmd.Parameters.Add("p_object_ID", objIds[objIdx]);//objId
        //                cmd.Parameters.Add("p_REQUESTER_MAIL", form[1]);//EmailID
        //                //DateTime dt = Convert.ToDateTime("15/Jan/2019 18:33:22 PM");
        //                //string time = new DateTime(dt.Ticks).ToString("hh:mm:ss"); 
        //                cmd.Parameters.Add("p_REQUEST_TIME", DateTime.Now.ToString("dd/MM/yyyy") + " " + DateTime.Now.TimeOfDay.ToString().Split('.')[0]);

        //                // cmd.Parameters.Add("p_REQUEST_TIME", _currentDate);
        //                string accountName = GetFullNameFromActiveDirectory(form[1]);
        //                if (accountName.Equals("Error"))
        //                {
        //                    @ViewData["ExcepMessage"] = "Error Occurred while retrieving the Requester Name";
        //                    FillDropDownListsControls();
        //                    return actionResult = View();
        //                }
        //                else
        //                {
        //                    cmd.Parameters.Add("p_requesterName", accountName); //Session["UserDisplayName"].ToString()
        //                }

        //                cmd.Parameters.Add("p_STATUS_ORG", "");

        //                cmd.Parameters.Add("p_DESCRIPTION", form[11]); //Description

        //                cmd.Parameters.Add("p_ASSIGNED_TO", "");

        //                cmd.Parameters.Add("p_EXPECTED_COMP_DATE", ""); //DueDate

        //                cmd.Parameters.Add("p_ACTUAL_COMP_DATE", "");

        //                cmd.Parameters.Add("p_PRIORITY", form[9]); //Grades

        //                cmd.Parameters.Add("p_PURPOSE", form[2]); //JobType

        //                cmd.Parameters.Add("p_MANAGER_COMMENTS", "");

        //                cmd.Parameters.Add("p_REQUESTER_ID", "");

        //                cmd.Parameters.Add("p_STATUS", "OPEN");

        //                cmd.Parameters.Add("p_PROJECT_NO", form[3]); //ProjectCode

        //                //cmd.Parameters.Add("p_PROJECT_NO", form[3]); //ProjectCode


        //                cmd.Parameters.Add("p_PROJECT_NAME", form[10]); //ProjectTitle
        //                //ViewData["ProjectTitle"] = true;
        //                cmd.Parameters.Add("p_STATUS_ID", "1");

        //                cmd.Parameters.Add("p_WORKQTY", form[4]); //Quantity

        //                cmd.Parameters.Add("p_CONTRACTOR_NAME", form[6].Split(',')[0]); //Contractors

        //                cmd.Parameters.Add("p_CONTRACTORID", form[6].Split(',')[1]);

        //                //cmd.Parameters.AddWithValue("@REQUESTER_MAIL", "svadakpuram@ashghal.gov.qa");

        //                cmd.Parameters.Add("p_REQUESTER_DEPT", form[7]); //Departments

        //                cmd.Parameters.Add("p_REFNO", form[8]); //DocRefNo

        //                //cmd.Parameters.Add("p_area", "");
        //                //cmd.Parameters.Add("p_areaUnit", "0");
        //                //cmd.Parameters.Add("p_surveyLoc", "");
        //                //cmd.Parameters.Add("p_isWP", "");
        //                //cmd.Parameters.Add("p_zone", "");

        //                // cmd.Parameters.AddWithValue("@p_MaxID", SqlDbType.Int).Direction = ParameterDirection.Output;

        //                // cmd.Parameters.AddWithValue("@USER_ID", "Hatheem");

        //                try
        //                {
        //                    con.Open();
        //                    cmd.ExecuteNonQuery();
        //                    con.Dispose();
        //                    Session["requestID"] = cmd.Parameters["p_request_ID"].Value.ToString();
        //                    ViewData["Message"] = "Survey Request Created Successfully having number :" + Session["requestID"] + ". Now create Survey Area as a polygon on the map.";
        //                    ViewData["createSRDisabled"] = true;
        //                }
        //                catch (Exception ex)
        //                {
        //                    ViewData["Message"] = null;
        //                    ViewData["ExcepMessage"] = "Error Occurred on first step while creating the Survey Request. Survey Request cannot be created.";
        //                    //throw ex;
        //                }
        //                try
        //                {
        //                    if (ViewData["Message"] != null)
        //                    {
        //                        //string[] surveyReqInfo = new string[20];
        //                        //surveyReqInfo[0] = Session["requestID"].ToString();
        //                        //surveyReqInfo[1] = form[2]; //JobType
        //                        //surveyReqInfo[2] = form[9]; //Priority
        //                        //surveyReqInfo[3] = Convert.ToDateTime(Session["DueDate"]).ToString("dd/MMM/yyyy"); // DueDate
        //                        //surveyReqInfo[4] = form[11]; //ProjectTitle
        //                        //surveyReqInfo[5] = " ";
        //                        //surveyReqInfo[6] = form[3]; //ProjectCode
        //                        //surveyReqInfo[7] = form[4]; //Quantity
        //                        //surveyReqInfo[8] = " ";
        //                        //surveyReqInfo[9] = form[7]; //Departments
        //                        //surveyReqInfo[10] = DateTime.Now.ToString("dd/MMM/yyyy"); // +" " + DateTime.Now.ToShortTimeString();
        //                        //surveyReqInfo[11] = "OPEN";
        //                        //surveyReqInfo[12] = form[6].Split(',')[0]; //Contractors
        //                        //surveyReqInfo[13] = form[6].Split(',')[1];
        //                        //surveyReqInfo[14] = accountName;
        //                        //surveyReqInfo[15] = " "; //txtArea.Text
        //                        //surveyReqInfo[16] = " "; //ddlUnits.SelectedIndex.ToString()
        //                        //surveyReqInfo[17] = " "; //ddlSurveyLoc.SelectedItem.Text
        //                        //surveyReqInfo[18] = " "; //ddlWP.SelectedValue
        //                        ////if (txtSurveyZone.Text.Trim().Equals(""))
        //                        ////{
        //                        //surveyReqInfo[19] = " "; //txtSurveyZone.Text

        //                        db.Database.ExecuteSqlCommand("InsertOrUpdateInSurveyInfoSQLServer @reqID,@purpose,@priority, @projTitle, @descrip, @projCode, @wkQty, @managerComnts," + //@dueDate
        //                                "@reqDept, @receiveDate, @status, @companyName, @companyId, @requesterName,@area,@areaUnit,@surveyLoc,@isWP,@zone",
        //                                new SqlParameter("reqID", Session["requestID"].ToString()),
        //                                new SqlParameter("purpose", form[2]), //JobType
        //                                new SqlParameter("priority", form[9]), //priority
        //                                new SqlParameter("dueDate", ""), //Convert.ToDateTime(Convert.ToDateTime(Session["DueDate"]).ToString("dd/MMM/yyyy") + " " + string.Format("{0:hh:mm:ss tt}", DateTime.Now))
        //                                new SqlParameter("projTitle", form[11]), //ProjectTitle
        //                                new SqlParameter("descrip", form[12]),
        //                                new SqlParameter("projCode", form[3]),
        //                                new SqlParameter("wkQty", form[4]),
        //                                new SqlParameter("managerComnts", DBNull.Value),
        //                                new SqlParameter("reqDept", form[7]),
        //                                new SqlParameter("receiveDate", DateTime.Now.ToString("dd/MMM/yyyy")),
        //                                new SqlParameter("status", "OPEN"),
        //                                new SqlParameter("companyName", form[6].Split(',')[0]),
        //                                new SqlParameter("companyId", form[6].Split(',')[1]),
        //                                new SqlParameter("requesterName", accountName),
        //                                new SqlParameter("area", " "),
        //                                new SqlParameter("areaUnit", " "),
        //                                new SqlParameter("surveyLoc", " "),
        //                                new SqlParameter("isWP", " "),
        //                                new SqlParameter("zone", " "));
        //                    }
        //                }
        //                catch (Exception ex)
        //                {
        //                    ViewData["ExcepMessage"] = "Error Occurred on second step while creating the Survey Request. Although, Survey Request has been successfully created on first step.";
        //                }
        //                finally
        //                {
        //                    con.Close();
        //                }
        //                //}
        //            }
        //        }
        //        //RedirectToAction("CreateSRWithMap");
        //        //FillDropDownListsControls();
        //        //if (Session["requestID"] != null)
        //        //{
        //        //    ViewData["createSRDisabled"] = false;
        //        //}
               
        //        actionResult = View();
        //        //ViewData["Text"] = HttpUtility.HtmlDecode(hdnInnerHtml.Replace("\r", "").Replace("\n", ""));                
        //    }
        //    else if (submit.StartsWith("Search"))
        //    {
        //        actionResult = RedirectToAction("SearchSurveyReq", "ServiceRequest");
        //    }
        //    else if (submit.StartsWith("Cancel"))
        //    {
        //        actionResult = RedirectToAction("ServiceRequest", "ServiceRequest");
        //    }
        //    else if (submit.StartsWith("Create"))
        //    {
        //        FillDropDownListsControls();
        //        //SearchSurveyReq(submit, form[1]);
        //        ViewData["emailID"] = form[1];
        //        ViewData["JobType"] = form[2];
        //        //ViewData.SelectedItem = form[2];
        //        ViewData["ProjectCode"] = form[3];
        //        ViewData["Quantity"] = form[4];
        //        ViewData["Contractor"] = form[5];
        //        ViewData["Department"] = form[6];
        //        ViewData["Priority"] = form[8];
        //        ViewData["DocRefNo"] = form[7];
        //        ViewData["ProjectTitle"] = form[9];
        //        ViewData["DescripAreaVal"] = form[10]; 
        //        actionResult = View();
        //    }
        //    ViewData["msg"] = "SURVEY REQUEST";
        //    return actionResult; //"<script>var settings = { map: map,layerInfos: featureLayerInfos }; var params = {settings: settings};" +
        //    //"editorWidget = new Editor(params, 'editorDiv');editorWidget.startup();map.enableSnapping();</script>");
        //}

        public ActionResult InsertAndUpdateSurveyRequest(object[] objIds, FormCollection form)
        {
            ActionResult actionResult = null;
            if (objIds != null)
            {
                for (short objIdx = 0; objIdx < objIds.Length; objIdx++)
                {

                    OracleConnection con = new OracleConnection(System.Configuration.ConfigurationManager.ConnectionStrings["SurveyConnOracle"].ConnectionString);

                    OracleCommand cmd = new OracleCommand();

                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Connection = con;
                    //if (submit.StartsWith("Submit"))
                    //{ 
                    cmd.CommandText = "InsertAndUpdateSurveyRequest";   // SP                         

                    OracleParameter result = new OracleParameter();
                    result.ParameterName = "p_request_ID";
                    result.OracleDbType = OracleDbType.Varchar2;
                    result.Direction = ParameterDirection.Output;
                    //result.Value = objIds[objIdx];
                    cmd.Parameters.Add(result);
                    //cmd.Parameters.Add("p_request_ID", OracleDbType.Int32).Direction = ParameterDirection.InputOutput;
                    //cmd.Parameters.Add(result); //"p_request_ID", surveyInfo[0].ToString());

                    //Console.WriteLine(); 
                    //cmd.Parameters.Add("p_request_ID", OracleDbType.Varchar2).Direction = ParameterDirection.InputOutput;
                    cmd.Parameters.Add("p_object_ID", objIds[objIdx]);//objId
                    cmd.Parameters.Add("p_REQUESTER_MAIL", form[1]);//EmailID
                    //DateTime dt = Convert.ToDateTime("15/Jan/2019 18:33:22 PM");
                    //string time = new DateTime(dt.Ticks).ToString("hh:mm:ss"); 
                    cmd.Parameters.Add("p_REQUEST_TIME", DateTime.Now.ToString("dd/MM/yyyy") + " " + DateTime.Now.TimeOfDay.ToString().Split('.')[0]);

                    // cmd.Parameters.Add("p_REQUEST_TIME", _currentDate);
                    string accountName = GetNameAndSetDeptFromAD(form[1]);
                    if (accountName.Equals("Error"))
                    {
                        @ViewData["ExcepMessage"] = "Error Occurred while retrieving the Requester Name";
                        FillDropDownListsControls();
                        return actionResult = View();
                    }
                    else
                    {
                        cmd.Parameters.Add("p_requesterName", accountName); //Session["UserDisplayName"].ToString()
                    }

                    cmd.Parameters.Add("p_STATUS_ORG", "");

                    cmd.Parameters.Add("p_DESCRIPTION", form[11]); //Description

                    cmd.Parameters.Add("p_ASSIGNED_TO", "");

                    cmd.Parameters.Add("p_EXPECTED_COMP_DATE", ""); //DueDate

                    cmd.Parameters.Add("p_ACTUAL_COMP_DATE", "");

                    cmd.Parameters.Add("p_PRIORITY", form[9]); //Grades

                    cmd.Parameters.Add("p_PURPOSE", form[2]); //JobType

                    cmd.Parameters.Add("p_MANAGER_COMMENTS", "");

                    cmd.Parameters.Add("p_REQUESTER_ID", "");

                    cmd.Parameters.Add("p_STATUS", "OPEN");

                    cmd.Parameters.Add("p_PROJECT_NO", form[3]); //ProjectCode

                    //cmd.Parameters.Add("p_PROJECT_NO", form[3]); //ProjectCode


                    cmd.Parameters.Add("p_PROJECT_NAME", form[10]); //ProjectTitle
                    //ViewData["ProjectTitle"] = true;
                    cmd.Parameters.Add("p_STATUS_ID", "1");

                    cmd.Parameters.Add("p_WORKQTY", form[4]); //Quantity

                    cmd.Parameters.Add("p_CONTRACTOR_NAME", form[6].Split(',')[0]); //Contractors

                    cmd.Parameters.Add("p_CONTRACTORID", form[6].Split(',')[1]);

                    //cmd.Parameters.AddWithValue("@REQUESTER_MAIL", "svadakpuram@ashghal.gov.qa");

                    cmd.Parameters.Add("p_REQUESTER_DEPT", form[7]); //Departments

                    cmd.Parameters.Add("p_REFNO", form[8]); //DocRefNo

                    //cmd.Parameters.Add("p_area", "");
                    //cmd.Parameters.Add("p_areaUnit", "0");
                    //cmd.Parameters.Add("p_surveyLoc", "");
                    //cmd.Parameters.Add("p_isWP", "");
                    //cmd.Parameters.Add("p_zone", "");

                    // cmd.Parameters.AddWithValue("@p_MaxID", SqlDbType.Int).Direction = ParameterDirection.Output;

                    // cmd.Parameters.AddWithValue("@USER_ID", "Hatheem");

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Dispose();
                        Session["requestID"] = cmd.Parameters["p_request_ID"].Value.ToString();
                        ViewData["Message"] = "Survey Request Created Successfully having number :" + Session["requestID"] + ". Now create Survey Area as a polygon on the map.";
                        ViewData["createSRDisabled"] = true;
                    }
                    catch (Exception ex)
                    {
                        ViewData["Message"] = null;
                        ViewData["ExcepMessage"] = "Error Occurred on first step while creating the Survey Request. Survey Request cannot be created.";
                        //throw ex;
                    }
                    try
                    {
                        if (ViewData["Message"] != null)
                        {
                            //string[] surveyReqInfo = new string[20];
                            //surveyReqInfo[0] = Session["requestID"].ToString();
                            //surveyReqInfo[1] = form[2]; //JobType
                            //surveyReqInfo[2] = form[9]; //Priority
                            //surveyReqInfo[3] = Convert.ToDateTime(Session["DueDate"]).ToString("dd/MMM/yyyy"); // DueDate
                            //surveyReqInfo[4] = form[11]; //ProjectTitle
                            //surveyReqInfo[5] = " ";
                            //surveyReqInfo[6] = form[3]; //ProjectCode
                            //surveyReqInfo[7] = form[4]; //Quantity
                            //surveyReqInfo[8] = " ";
                            //surveyReqInfo[9] = form[7]; //Departments
                            //surveyReqInfo[10] = DateTime.Now.ToString("dd/MMM/yyyy"); // +" " + DateTime.Now.ToShortTimeString();
                            //surveyReqInfo[11] = "OPEN";
                            //surveyReqInfo[12] = form[6].Split(',')[0]; //Contractors
                            //surveyReqInfo[13] = form[6].Split(',')[1];
                            //surveyReqInfo[14] = accountName;
                            //surveyReqInfo[15] = " "; //txtArea.Text
                            //surveyReqInfo[16] = " "; //ddlUnits.SelectedIndex.ToString()
                            //surveyReqInfo[17] = " "; //ddlSurveyLoc.SelectedItem.Text
                            //surveyReqInfo[18] = " "; //ddlWP.SelectedValue
                            ////if (txtSurveyZone.Text.Trim().Equals(""))
                            ////{
                            //surveyReqInfo[19] = " "; //txtSurveyZone.Text

                            db.Database.ExecuteSqlCommand("InsertOrUpdateInSurveyInfoSQLServer @reqID,@purpose,@priority, @projTitle, @descrip, @projCode, @wkQty, @managerComnts," + //@dueDate
                                    "@reqDept, @receiveDate, @status, @companyName, @companyId, @requesterName,@area,@areaUnit,@surveyLoc,@isWP,@zone",
                                    new SqlParameter("reqID", Session["requestID"].ToString()),
                                    new SqlParameter("purpose", form[2]), //JobType
                                    new SqlParameter("priority", form[9]), //priority
                                    new SqlParameter("dueDate", ""), //Convert.ToDateTime(Convert.ToDateTime(Session["DueDate"]).ToString("dd/MMM/yyyy") + " " + string.Format("{0:hh:mm:ss tt}", DateTime.Now))
                                    new SqlParameter("projTitle", form[11]), //ProjectTitle
                                    new SqlParameter("descrip", form[12]),
                                    new SqlParameter("projCode", form[3]),
                                    new SqlParameter("wkQty", form[4]),
                                    new SqlParameter("managerComnts", DBNull.Value),
                                    new SqlParameter("reqDept", form[7]),
                                    new SqlParameter("receiveDate", DateTime.Now.ToString("dd/MMM/yyyy")),
                                    new SqlParameter("status", "OPEN"),
                                    new SqlParameter("companyName", form[6].Split(',')[0]),
                                    new SqlParameter("companyId", form[6].Split(',')[1]),
                                    new SqlParameter("requesterName", accountName),
                                    new SqlParameter("area", " "),
                                    new SqlParameter("areaUnit", " "),
                                    new SqlParameter("surveyLoc", " "),
                                    new SqlParameter("isWP", " "),
                                    new SqlParameter("zone", " "));
                        }
                    }
                    catch (Exception ex)
                    {
                        ViewData["ExcepMessage"] = "Error Occurred on second step while creating the Survey Request. Although, Survey Request has been successfully created on first step.";
                    }
                    finally
                    {
                        con.Close();
                    }
                    //}
                }
            }
            return View();
        }

        //// GET: /ServiceRequest/CreateSR
        public ActionResult CreateSR()
        {
            //Session["ArcGISTiledMapServiceLayerUrl"] = ConfigurationManager.AppSettings["ArcGISTiledMapServiceUrl"].ToString();
            //Session["CadastralPlotsServiceUrl"] = ConfigurationManager.AppSettings["CadastralPlotsServiceUrl"].ToString();
            //Session["Control95ServiceUrl"] = ConfigurationManager.AppSettings["Control95ServiceUrl"].ToString();
            //Session["ImageServiceUrl"] = ConfigurationManager.AppSettings["ImageServiceUrl"].ToString();
            //Session["PolicyPlanPlotServiceUrl"] = ConfigurationManager.AppSettings["PolicyPlanPlotServiceUrl"].ToString();
            //Session["FeatureLayerUrl"] = ConfigurationManager.AppSettings["FeatureLayerUrl"].ToString();
            //Session["GeoProcessorUrl"] = ConfigurationManager.AppSettings["GeoProcessorUrl"].ToString();
            SetServiceRequestSecondHeading();
            //this.SetDisbaledProperties(false);
            EBDServiceRequests ebdServiceRequests = new EBDServiceRequests();
            ebdServiceRequests.serviceRequestDate = new DateTime?(DateTime.Now);
            this.FillDepartments();
            Session["DepartmentID"] = " ";
            this.FillSections();
            Session["SectionID"] = " ";
            this.FillServiceTypes();
            this.FillAndSetServiceTypeSubCategory(1, 0, false);
            return base.View(ebdServiceRequests);            
        }

        static bool isCreated = false;

        //// POST: /ServiceRequest/CreateSR
        //// To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        //// more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult CreateSR([Bind(Include = "empName,departmentID,sectionID,jobTitle,phoneNumber,onBehalfOf,emailID,serviceRequestDate,serviceRequestDescription,fileName,filePath,serviceTypeID,serviceTypeSystemID")] EBDServiceRequests ebdservicerequests,
            string submit, FormCollection form, HttpPostedFileBase[] files)
        {
            ActionResult actionResult = null;
            Session["EmpName"] = "";
            Session["JobTitle"] = "";
            Session["PhoneNumber"] = "";
            Session["DepartmentID"] = "";
            Session["SectionID"] = "";
            try 
	        {      
                if (base.ModelState.IsValid)
                {
                    if (submit.StartsWith("Create") || submit.StartsWith("إنشاء"))
                    {
                        //string keyValue = null;
                        //if (Request.Cookies["key"] != null)
                        //{
                        //    keyValue = Request.Cookies["key"].Value;
                        //}
                        //if (keyValue == "1")
                        //{
                            
                            DateTime servReqDate = Convert.ToDateTime(form["serviceRequestDate"]);

                            short departmentID = 0;
                            short sectionID = 0;
                            short serviceTypeID = 0;
                            short serviceTypeSystemID = 0;
                            serviceTypeID = Convert.ToInt16(form["ServiceTypes"].ToString());
                            serviceTypeSystemID = Convert.ToInt16(form["ServiceTypeSubCategory"].ToString());

                            //if (base.TempData["DepId"] != null || form["Departments"] != null)
                            //{                         
                            if (form["Departments"] != null)
                            {
                                departmentID = Convert.ToInt16(form["Departments"]);
                            }
                            if (form["Sections"] != null)
                            {
                                sectionID = Convert.ToInt16(form["Sections"]);
                            }

                            IQueryable<Contact> queryable = null;
                            string empName = form["empName"];
                            try
                            {

                                if (form["emailID"] != null)
                                {
                                    string emailID = form["emailID"];
                                    queryable = from c in this.db.Contact
                                                where c.emailAddress.Contains(emailID)
                                                select c;

                                    if (queryable.Count<Contact>() > 0)
                                    {
                                        ebdservicerequests.contactID = queryable.Select(t => t.contactID).AsEnumerable<int>().First<int>();
                                    }
                                    else
                                    {
                                        DirectoryEntry directoryEntry2 = GetUserInfoFromActiveDirectory(emailID);
                                        string contactName = null;
                                        string contactJobTitle = null;
                                        string contactTelPhoneNumber = null;

                                        if (directoryEntry2.Properties["cn"] != null)
                                        {
                                            if (directoryEntry2.Properties["cn"][0] != null)
                                            {
                                                contactName = directoryEntry2.Properties["cn"][0].ToString().Trim();
                                            }
                                            else
                                            {
                                                contactName = empName;
                                            }
                                        }
                                        else
                                        {
                                            contactName = empName;
                                        }

                                        if (directoryEntry2.Properties["title"].Value != null)
                                        {
                                            if (directoryEntry2.Properties["title"][0] != null)
                                            {
                                                contactJobTitle = directoryEntry2.Properties["title"][0].ToString();
                                            }
                                            else
                                            {
                                                contactJobTitle = Server.HtmlEncode(form["jobTitle"]);
                                            }
                                        }
                                        else
                                        {
                                            contactJobTitle = Server.HtmlEncode(form["jobTitle"]);
                                        }

                                        if (directoryEntry2.Properties["telephoneNumber"].Value != null)
                                        {
                                            if (directoryEntry2.Properties["telephoneNumber"][0] != null)
                                            {
                                                contactTelPhoneNumber = directoryEntry2.Properties["telephoneNumber"][0].ToString();
                                            }
                                            else
                                            {
                                                contactTelPhoneNumber = Server.HtmlEncode(form["phoneNumber"]);
                                            }
                                        }
                                        else
                                        {
                                            contactTelPhoneNumber = Server.HtmlEncode(form["phoneNumber"]);
                                        }

                                        SqlParameter contactIDParam = new SqlParameter();
                                        contactIDParam.ParameterName = "@contactID";
                                        contactIDParam.DbType = DbType.Int32;
                                        contactIDParam.Direction = ParameterDirection.Output;
                                        contactIDParam.Value = 0;
                                        string contactLastName = null;
                                        for (int counter = 0; counter < contactName.Split(' ').Length; counter++)
                                        {
                                            if (counter != 0)
                                            {
                                                contactLastName += contactName.Split(' ')[counter] + " ";
                                            }
                                        }

                                        if (contactName != null)
                                        {
                                            db.Database.ExecuteSqlCommand("InsertUpdateContact @contactID OUTPUT,@firstName,@middleName,@lastName,@companyID,@sectionID,@teamLeaderID,@officeAddress,@officePhone,@mobPhone,@country,@emailAddress,@jobPosition," +
                                            "@currentUser,@userComments,@userShortName,@isAuthRepres,@isCoordinator", contactIDParam,
                                            new SqlParameter("firstName", contactName.Split(' ')[0]),
                                            new SqlParameter("middleName", DBNull.Value),
                                            new SqlParameter("lastName", contactLastName.TrimEnd()),
                                            new SqlParameter("companyID", 1),
                                            new SqlParameter("sectionID", 8),
                                            new SqlParameter("teamLeaderID", 6),
                                            new SqlParameter("officeAddress", DBNull.Value),
                                            new SqlParameter("officePhone", contactTelPhoneNumber),
                                            new SqlParameter("mobPhone", DBNull.Value),
                                            new SqlParameter("country", DBNull.Value),
                                            new SqlParameter("emailAddress", emailID),
                                            new SqlParameter("jobPosition", contactJobTitle),
                                            new SqlParameter("currentUser", DBNull.Value),
                                            new SqlParameter("userComments", DBNull.Value),
                                            new SqlParameter("userShortName", DBNull.Value),
                                            new SqlParameter("isAuthRepres", Convert.ToInt16(1)),
                                            new SqlParameter("isCoordinator", Convert.ToInt16(1)));
                                            ebdservicerequests.contactID = Convert.ToInt32(contactIDParam.Value);
                                        }
                                        else
                                        {
                                            DisplayCreateSR(serviceTypeID, serviceTypeSystemID, ebdservicerequests, form);
                                            ViewData["ExcepMessage"] = "Employee Name does not exists. Cannot create Service Request.";
                                            return View(ebdservicerequests);
                                        }
                                    }
                                }

                                string filePath = null;

                                string jobNo = null;
                                if ((from ebdServReq in db.EBDServiceRequests
                                     where ebdServReq.serviceRequestDate.Value.Year.ToString().Contains(DateTime.Now.Year.ToString())
                                     select ebdServReq.serviceReqID).AsEnumerable<int>().Count<int>() > 0)
                                {
                                    jobNo = (from ebdServReq in db.EBDServiceRequests
                                             let jobNoVal = db.EBDServiceRequests.Where(j => j.serviceRequestDate.Value.Year.ToString().Contains(DateTime.Now.Year.ToString())
                                             ).Select(j => j.serviceReqNo).Cast<string>().Max()
                                             select jobNoVal).First();
                                    int incJobNoDigits = Convert.ToInt32(jobNo.Substring(2)) + 1;
                                    jobNo = "BD" + incJobNoDigits;
                                }
                                else
                                {
                                    jobNo = "BD" + DateTime.Now.Year.ToString().Substring(2) + "0001";
                                }

                                int tlID = 0;
                                tlID = Convert.ToInt32((from tlColID in this.db.ModuleAccess
                                                        where tlColID.ProfileID == 1
                                                        select tlColID).First().ContactID);

                                //var jobIDParam = new SqlParameter();
                                //jobIDParam.ParameterName = "@jobID";
                                //jobIDParam.DbType = DbType.Int32;
                                //jobIDParam.Direction = ParameterDirection.Output;

                                if (files[0] != null)
                                {
                                    filePath = ConfigurationManager.AppSettings["fileUploadServiceRequest"].ToString();
                                    filePath = filePath + "\\" + jobNo;
                                    //iterating through multiple file collection   
                                    foreach (HttpPostedFileBase file in files)
                                    {
                                        //Checking file is available to save.  
                                        if (file != null)
                                        {
                                            if (!System.IO.Directory.Exists(filePath))
                                                System.IO.Directory.CreateDirectory(filePath);
                                            file.SaveAs(filePath + "\\" + jobNo + "_" + file.FileName.Substring(file.FileName.LastIndexOf("\\") + 1));
                                        }
                                    }
                                    ViewData["FileUploadMessage"] = "Files uploaded successfully";
                                }

                                db.Database.ExecuteSqlCommand("BS_CreateServiceRequest @contactID,@tlContactID, @jobNo, @serviceRequestDate, @empName, @departmentID, @sectionID, @jobTitle, @phoneNumber," +
                                "@emailID, @serviceRequestDescription, @onBehalfOf, @serviceTypeID, @serviceTypeSystemID, @filePath",
                                new SqlParameter("contactID", ebdservicerequests.contactID),
                                new SqlParameter("tlContactID", tlID),
                                new SqlParameter("jobNo", jobNo),
                                new SqlParameter("serviceRequestDate", Convert.ToDateTime(ebdservicerequests.serviceRequestDate.ToString().Split(' ')[0] + " " + string.Format("{0:hh:mm:ss tt}", DateTime.Now))),
                                new SqlParameter("empName", Server.HtmlEncode(form["empName"])),
                                new SqlParameter("departmentID", departmentID),
                                new SqlParameter("sectionID", sectionID),
                                new SqlParameter("jobTitle", Server.HtmlEncode(form["jobTitle"])),
                                new SqlParameter("phoneNumber", Server.HtmlEncode(form["phoneNumber"])),
                                new SqlParameter("emailID", ebdservicerequests.emailID),
                                new SqlParameter("serviceRequestDescription", Server.HtmlEncode(ebdservicerequests.serviceRequestDescription.Replace("\n", "").Replace("'", "''").Replace("\r", ""))),
                                new SqlParameter("onBehalfOf", Server.HtmlEncode(form["onBehalfOf"])),
                                new SqlParameter("serviceTypeID", serviceTypeID),
                                new SqlParameter("serviceTypeSystemID", serviceTypeSystemID),
                                new SqlParameter("filePath", (object)filePath ?? DBNull.Value)); //,
                                //////new SqlParameter("fileName", (object)fileName ?? DBNull.Value));   //,jobIDParam                                                              
                                //////object jobId = jobIDParam.Value;                             

                                ViewData["Message"] = "Service Request Created Successfully with Job No. :" + jobNo;

                                var emailId = from c in this.db.Contact
                                              where c.contactID == tlID
                                              select new { c.emailAddress };

                                foreach (var item in emailId)
                                {
                                    SendEmail(ebdservicerequests.emailID, item.emailAddress, jobNo, ebdservicerequests.serviceRequestDescription);
                                }
                            }
                            catch (Exception ex)
                            {
                                ViewData["Message"] = "Error Occurred while creating the service request. Try again, and if the problem persists contact your system administrator." + ex.Message.Replace("'", "");
                            }
                            //Request.Cookies["key"].Value = "0";
                            //actionResult = RedirectToAction("ServiceRequest", "ServiceRequest");
                            DisplayCreateSR(serviceTypeID, serviceTypeSystemID, ebdservicerequests, form);
                            actionResult = base.View(ebdservicerequests);
                            //} 
                            //else
                            //{
                            //    actionResult = CreateSR();
                            //}    
                        //}       
                    }
                    else if (submit.StartsWith("Validate") || submit.StartsWith("التحقق"))                  
                    {                             
                        short serviceTypeID = 0;
                        short serviceTypeSystemID = 0;
                        serviceTypeID = Convert.ToInt16(form["ServiceTypes"].ToString());
                        serviceTypeSystemID = Convert.ToInt16(form["ServiceTypeSubCategory"].ToString());
                        CheckUserInfo(ebdservicerequests,form);
                        this.FillServiceTypes();
                        if (serviceTypeID == 0)
                        {
                            serviceTypeID = 1;
                        }
                        FillAndSetServiceTypeSubCategory(serviceTypeID, serviceTypeSystemID, false);
                        actionResult = base.View(ebdservicerequests);
                    }
                    else if (submit.StartsWith("Search") || submit.StartsWith("بحث"))
                    {
                        actionResult = RedirectToAction("SearchSR", "ServiceRequest");
                    }
                    else if (submit.StartsWith("Cancel") || submit.StartsWith("إلغاء"))
                    {
                        actionResult = RedirectToAction("ServiceRequest", "ServiceRequest");
                    }          
                }
                else if (submit.StartsWith("Search") || submit.StartsWith("بحث"))
                {
                    actionResult = RedirectToAction("SearchSR", "ServiceRequest");
                }
                else if (submit.StartsWith("Cancel") || submit.StartsWith("إلغاء"))
                {
                    actionResult = RedirectToAction("ServiceRequest", "ServiceRequest");
                }   
                else
                {
                    ViewData["ExcepMessage"] = "Error Occurred invalid EmailID";
                    actionResult = CreateSR();
                }
                SetServiceRequestSecondHeading();            
            }
            catch (Exception ex)
            {
                ViewData["ExcepMessage"] = "Error Occurred invalid Service Request Date";
                actionResult = CreateSR();
            }
            return actionResult; 
        }

        private void CheckUserInfo([Bind(Include = "empName,departmentID,sectionID,jobTitle,phoneNumber,onBehalfOf,emailID,serviceRequestDate,serviceRequestDescription,fileName,filePath,serviceTypeID,serviceTypeSystemID")] EBDServiceRequests ebdservicerequests,
            FormCollection form)
        {            
            string emailID = form["emailID"];
            IQueryable<Contact> queryContact = (from ct in db.Contact
                                                where ct.emailAddress == emailID
                                                select ct);

            if (queryContact.Count<Contact>() != 0)
            {
                FillDepartments();
                FillSections();

                int? deptId = queryContact.Select(t => t.deptID).AsEnumerable<int?>().First<int?>();
                int? sectId = queryContact.Select(t => t.sectionID).AsEnumerable<int?>().First<int?>();

                if (deptId != null)
                {
                    Session["DepartmentID"] = deptId;
                }
                else
                {
                    Session["DepartmentID"] = "1"; //1-> "Not Applicable";
                }

                if (sectId != null)
                {
                    Session["SectionID"] = sectId;
                }
                else
                {
                    Session["SectionID"] = "8";//8->"Not Applicable";
                }

                Session["EmpName"] = queryContact.Select(t => t.firstName).AsEnumerable<string>().First<string>() + " " + queryContact.Select(t => t.lastName).AsEnumerable<string>().First<string>(); //,ct.lastName
                Session["JobTitle"] = queryContact.Select(t => t.jobPosition).AsEnumerable<string>().First<string>();
                Session["PhoneNumber"] = queryContact.Select(t => t.officePhone).AsEnumerable<string>().First<string>();
            }
            else
            {
                //this.SetDisbaledProperties(false);
                this.GetDataFromActiveDirectory(ebdservicerequests);
            }
        }


        void SetServiceRequestSecondHeading()
        {
            if (Request.Cookies["culture"] != null)
            {
                if (Request.Cookies["culture"].Value == "en")
                {
                    ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
                    ViewData["msg"] = "SERVICE REQUEST";
                }
                else
                {
                    ViewData["firstHeading"] = EBDServiceRequest.ResourceAr.firstHeading;
                    ViewData["msg"] = "طلب خدمة";
                }
            }
            else
            {
                ViewData["firstHeading"] = EBDServiceRequest.Resource.firstHeading;
                ViewData["msg"] = "SERVICE REQUEST";
            }
        }
        private void DisplayCreateSR(short serviceTypeID, short serviceTypeSystemID, EBDServiceRequests ebdservicerequests,FormCollection form)
        {
            CheckUserInfo(ebdservicerequests, form);
            this.FillServiceTypes();
            this.FillAndSetServiceTypeSubCategory(serviceTypeID, serviceTypeSystemID,false);
            
        }


        public ActionResult FillContractors()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            list.Add(new SelectListItem
            {
                Text = "",
                Value = ""
            });

            try
            {
                //foreach (DataRow item in GetData("SELECT distinct CONTRACTORID,CONTRACTOR_NAME FROM Survey_Info where CONTRACTORID is not Null " +
                //"and CONTRACTORID<>0", false).Rows)
                //{
                //    list.Add(new SelectListItem
                //    {
                //        Text = item["CONTRACTOR_NAME"].ToString(),
                //        Value = item["CONTRACTORID"].ToString()
                //    });
                //}
               
                foreach (DataRow item in GetData("SELECT distinct CMP_ID,COMPANY_NAME FROM SURVEY_COMPANIES", false).Rows)
                {
                    list.Add(new SelectListItem
                    {
                        Text = item["COMPANY_NAME"].ToString(),
                        Value = item["CMP_ID"].ToString()
                    });
                }
                list.Add(new SelectListItem
                {
                    Text = "Other",
                    Value = "Other"
                });
            }
            catch (Exception)
            {
                ViewData["ExcepMessage"] = "Error occurred while retrieving the information. Oracle Survey DB is down. Inform Application Administrator";
            }
            
            ViewData["Contractors"] = list;
            //ViewData["Contractor"] = list[0];
            return base.View();

            //List<SelectListItem> list = new List<SelectListItem>();
            //foreach (Company current in ((IEnumerable<Company>)this.db.Company))
            //{
            //    list.Add(new SelectListItem
            //    {
            //        Text = current.cmpName,
            //        Value = current.cmpName
            //    });
            //}
            //ViewBag.Departments = list;
            //return base.View();

            //foreach (DataRow item in GetData("select Distinct cmpName from Company","cmpName",true).Rows)
            //{
            //    list.Add(new SelectListItem
            //    {
            //        Text = item["cmpName"].ToString(),
            //        Value = item["cmpName"].ToString()
            //    });
            //}

            //ViewBag.Contractors = list;
            //return base.View();
        }

        private void SelectItemFromDDL(string deptName)
        {
            foreach (Department current in ((IEnumerable<Department>)this.db.Department))
            {
                if (current.deptName.Contains(deptName))
                {
                    Session["DepartmentID"] = deptName;
                    //ViewData["Departments"] = ((IEnumerable<SelectListItem>)ViewData["Departments"]).Select(c => new SelectListItem { Text = deptName, Value = deptName, Selected=true }).ToList();
                    //Session["SelectDept"] = current.deptName;                      
                }
            }
            //ViewData["Departments"] = deptList;            
        }
        //SELECT distinct CONTRACTORID,CONTRACTOR_NAME FROM Survey_Info where CONTRACTORID is not Null and CONTRACTORID<>0

        //public ActionResult FillJobTypes() //string selectedItem
        //{
        //    List<SelectListItem> list = new List<SelectListItem>();
        //    list.Add(new SelectListItem
        //    {
        //        Text = "",
        //        Value = ""
        //    });

        //    try
        //    {
        //        var queryable = (from si in db.SURVEY_INFO
        //                        where si.PURPOSE!="13" && si.PURPOSE!="11" && si.PURPOSE!="12"
        //                        && si.PURPOSE != "Old" && si.PURPOSE != "10" && si.PURPOSE != "9" && si.PURPOSE != ""
        //                        select new { si.PURPOSE }).Distinct();

        //        foreach (var item in queryable)
        //        {
        //            list.Add(new SelectListItem
        //            {
        //                Text = item.PURPOSE,
        //                Value = item.PURPOSE
        //            });
        //        }
        //        //foreach (DataRow item in GetData("SELECT distinct Purpose from survey_info where Purpose<>'13' and Purpose<>'11' and Purpose<>'12' " +
        //        //"and Purpose<>'Old' and Purpose<>'10' and Purpose<>'9'", false).Rows)
        //        //{
        //        //    list.Add(new SelectListItem
        //        //    {
        //        //        Text = item["purpose"].ToString(),
        //        //        Value = item["purpose"].ToString()
        //        //    });
        //        //}
        //    }
        //    catch (Exception)
        //    {
        //        ViewData["ExcepMessage"] = "Error occurred while retrieving the information. Oracle Survey DB is down. Inform Application Administrator";
        //    }
                        
        //    ViewData["JobTypes"] = list;
        //    //ViewData["JobType"] = list[0].Text;
        //    return base.View();
        //}

        public ActionResult FillPriority() //string selectedItem
        {
            List<SelectListItem> list = new List<SelectListItem>();
            //var categoryList = new SelectList(new[] { "Normal", "Urgent" });
            //ViewData["Grades"] = categoryList;

            list.Add(new SelectListItem
            {
                Text = "Normal",
                Value = "Normal"
            });
            list.Add(new SelectListItem
            {
                Text = "Urgent",
                Value = "Urgent"
            });
            ViewData["Priorities"] = list;
            //ViewData["PriorityVal"] = list[0];
            return base.View();
        }

        public ActionResult FillUnits()
        {
            //List<SelectListItem> list = new List<SelectListItem>();
            List<SelectListItem> list = new List<SelectListItem>();
            //var categoryList = new SelectList(new[] { "Normal", "Urgent" });
            //ViewData["Grades"] = categoryList;

            list.Add(new SelectListItem
            {
                Text = "Kms",
                Value = "Kms"
            });
            list.Add(new SelectListItem
            {
                Text = "SqKms",
                Value = "SqKms",
                Selected = true
            });
            list.Add(new SelectListItem
            {
                Text = "Hectares",
                Value = "Hectares",
                Selected = true
            });
             
            //if(selectedItem != null)
            //{
            //    list = SelectItemFromTheList(list, selectedItem);
            //    //selLst = new SelectList(list, selectedItem);
            //}

            SelectListItem selList = new SelectListItem { Text = "SqKms", Value = "SqKms", Selected = true };
            
            ViewData["Units"] = list;
            //ViewData["PriorityVal"] = list[0];
            return base.View();
        }

        List<SelectListItem> deptList = null;

        public ActionResult FillDeptOraDB()
        {
            deptList = new List<SelectListItem>();
            deptList.Add(new SelectListItem
            {
                Text = "",
                Value = ""
            });

            try
            {
                foreach (DataRow item in GetData("select Distinct requester_dept from survey_info where requester_dept is not Null order by REQUESTER_DEPT", true).Rows)
                {
                    deptList.Add(new SelectListItem
                    {
                        Text = item["requester_dept"].ToString(),
                        Value = item["requester_dept"].ToString()
                    });
                }
                //list.Add(new SelectListItem
                //{
                //    Text = "Other",
                //    Value = "Other"
                //});
            }
            catch (Exception)
            {
                ViewData["ExcepMessage"] = "Error occurred while retrieving the information. Oracle Survey DB is down. Inform Application Administrator";
            }

            ViewData["Departments"] = deptList;
            return base.View();
        }

        
        public ActionResult FillDepartments()
        {
            deptList = new List<SelectListItem>();
            IQueryable<Department> queryable = from dept in db.Department
                                               where dept.isActive.ToString().Contains("True")
                                               select dept;             
            //deptList.Add(new SelectListItem
            //{  
            //    Text = "",
            //    Value = ""
            //});

            foreach (Department item in queryable)
            {
                deptList.Add(new SelectListItem
                {
                    Text = item.newDeptName,
                    Value = item.newDeptID.ToString()
                });
            }
            
            ViewData["Departments"] = deptList;
            return base.View();
        }

        public ActionResult SetDepartment(EBDServiceRequests ebdServiceReq)
        {
            List<SelectListItem> list = new List<SelectListItem>();

            IQueryable<Department> queryable = from dept in db.Department
                                               where dept.departmentID == ebdServiceReq.departmentID
                                               select dept;

            foreach (Department item in queryable)
	        {
                list.Add(new SelectListItem
                {
                    Text = item.deptName,
                    Value = item.departmentID.ToString()
                });
	        }
             
            ViewBag.Departments = list;
            return base.View();
        }

        public ActionResult SetSection(EBDServiceRequests ebdServiceReq)
        {
            List<SelectListItem> list = new List<SelectListItem>();

            IQueryable<Section> queryable = from sect in db.Section
                                               where sect.sectionID == ebdServiceReq.sectionID
                                               select sect;

            foreach (Section item in queryable)
            {
                list.Add(new SelectListItem
                {
                    Text = item.sectionName,
                    Value = item.sectionID.ToString()
                });
            }

            ViewBag.Sections = list;
            return base.View();
        }

        public ActionResult FillSections()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            //list.Add(new SelectListItem
            //{
            //    Text = "",
            //    Value = ""
            //});
            IQueryable<Section> queryable = from sec in this.db.Section
                                                where sec.sectionID != 7 
                                                select sec;
            foreach (Section current in ((IEnumerable<Section>)queryable))
            {
                list.Add(new SelectListItem
                {
                    Text = current.sectionName,
                    Value = current.sectionID.ToString()
                });
            }
            ViewData["Sections"] = list;
            return base.View();
        }

        private ActionResult FillServiceTypes()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            IQueryable<ServiceType> queryable = from svcType in this.db.ServiceType
                                                where svcType.serviceTypeID != 4
                                                select svcType;
            foreach (ServiceType current in ((IEnumerable<ServiceType>)queryable))
            {
                list.Add(new SelectListItem
                {
                    Text = current.serviceTypeDescription,
                    Value = current.serviceTypeID.ToString()
                });
            }
            ViewData["ServiceTypes"] = list;
            return base.View();
        }

        private JsonResult FillAndSetServiceType(EBDServiceRequests serviceReq, bool isView)
        {
            List<SelectListItem> list = new List<SelectListItem>();
            if (!isView)
            {
                IQueryable<ServiceType> queryable = from svcType in this.db.ServiceType
                                                    where svcType.serviceTypeID != 4
                                                    select svcType;
                foreach (ServiceType current in ((IEnumerable<ServiceType>)queryable))
                {
                    list.Add(new SelectListItem
                    {
                        Text = current.serviceTypeDescription,
                        Value = current.serviceTypeID.ToString()
                    });
                }
                

                (from x in list
                 where x.Value == serviceReq.serviceTypeID.ToString()
                 select x).First<SelectListItem>().Selected = true;
            }
            else
            {
                IQueryable<ServiceType> queryable = from svcType in this.db.ServiceType
                                                    where svcType.serviceTypeID == serviceReq.serviceTypeID
                                                    select svcType;

                foreach (ServiceType current in ((IEnumerable<ServiceType>)queryable))
                {
                    list.Add(new SelectListItem
                    {
                        Text = current.serviceTypeDescription,
                        Value = current.serviceTypeID.ToString()
                    });
                }
            }            

            ViewData["ServiceTypes"] = list;
            return base.Json(list, JsonRequestBehavior.AllowGet);
        }

        //private string GetEndDateByGivenDays(int _days, string strDate)
        //{
        //    SqlConnection con = new SqlConnection(connValue);
        //    SqlCommand cmd = new SqlCommand();
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.Connection = con;

        //    cmd.CommandText = "AddWorkdays";
        //    SqlParameter prm = cmd.Parameters.Add("@ad_startDate", SqlDbType.DateTime);
        //    prm.Value = strDate;
        //    prm = cmd.Parameters.Add("@actual_workDays", SqlDbType.Int);
        //    prm.Value = Convert.ToInt32(_days);
        //    prm = cmd.Parameters.Add("@endDate", SqlDbType.DateTime);
        //    prm.Direction = ParameterDirection.Output;
        //    con.Open();
        //    SqlDataReader dr = cmd.ExecuteReader();
        //    while (dr.Read())
        //        Console.WriteLine(dr.GetString(0));
        //    con.Dispose();
        //    con.Close();

        //    return cmd.Parameters[2].Value.ToString();
        //}

        public JsonResult FillSectionBasedOnDept(short depId)
        {
            List<SelectListItem> list = new List<SelectListItem>();
            //if (depId != 22 && depId != 8 && depId != 20)
            //{
            //    depId = 2;
            //}

            var queryable = from dpt in db.Department
                            join dpt1 in db.Department on dpt.newDeptID equals dpt1.departmentID          
                            join sec in db.Section on dpt.departmentID equals sec.departmentID
                            where (dpt.newDeptID == depId)
                            select new { sec.sectionName,sec.sectionID };


            foreach (var item in queryable)
            {
                list.Add(new SelectListItem
                {
                    Text = item.sectionName,
                    Value = item.sectionID.ToString()
                });
            }
            if (list.Count() == 0)
            {
                list.Add(new SelectListItem
                {
                    Text = "Not Applicable",
                    Value = "8"
                });
            }
            ViewData["Sections"] = list;
            return base.Json(list, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetEndDateByGivenDays(int days, string strDate)
        {
            string lastDate = null;
            var dueDate = new SqlParameter();
            try
            {
                dueDate.ParameterName = "@endDate";
                dueDate.SqlDbType = SqlDbType.NVarChar;
                dueDate.Size = 100;
                dueDate.Direction = ParameterDirection.Output;
                db.Database.ExecuteSqlCommand("AddWorkdays @ad_startDate,@actual_workDays,@endDate out",
                new SqlParameter("ad_startDate", Convert.ToDateTime(strDate)),
                new SqlParameter("actual_workDays", days),dueDate);
                lastDate = Convert.ToDateTime(dueDate.Value).ToString("dd/MMM/yyyy");
                Session["DueDate"] = lastDate;
            }
            catch (Exception ex)
            {
                lastDate = "Error Occurred while retrieving the date";                 
            }

            return base.Json(lastDate, JsonRequestBehavior.AllowGet);
        }

        public JsonResult FillAndSetServiceTypeSubCategory(short? serviceTypeID, short? serviceTypeSystemID, bool isView)
        {
            List<SelectListItem> list = new List<SelectListItem>();
            if (!isView)
            {
                IQueryable<ServiceTypeSubCategory> queryable = from svcSubCat in this.db.ServiceTypeSubCategory
                                                               where (int?)svcSubCat.serviceTypeID == (int?)((int)serviceTypeID)
                                                               select svcSubCat;
                if (queryable.Count<ServiceTypeSubCategory>() != 0)
                {
                    foreach (ServiceTypeSubCategory current in queryable)
                    {
                        list.Add(new SelectListItem
                        {
                            Text = current.serviceTypeSystem,
                            Value = current.serviceTypeSystemID.ToString()
                        });
                    }                     
                }
            }
            else
            {
                IQueryable<ServiceTypeSubCategory> queryable = from svcSubCat in this.db.ServiceTypeSubCategory
                                                               where (int?)svcSubCat.serviceTypeID == (int?)((int)serviceTypeID)
                                                               && (int?)svcSubCat.serviceTypeSystemID == (int?)((int)serviceTypeSystemID) 
                                                               select svcSubCat;

                foreach (ServiceTypeSubCategory current in queryable)
                {
                    list.Add(new SelectListItem
                    {
                        Text = current.serviceTypeSystem,
                        Value = current.serviceTypeSystemID.ToString()
                        
                    });
                }
            }
            
            ViewData["ServiceTypeSubCategory"] = list;
            return base.Json(list, JsonRequestBehavior.AllowGet);
        }
         

        public FileResult DownloadFiles(string filePath,string fileName)
        {
            byte[] fileBytes = System.IO.File.ReadAllBytes(filePath);

            //return new FilePathResult(filePath.Split('\\')[filePath.Split('\\').Length - 1], System.Net.Mime.MediaTypeNames.Application.Octet);
            //string fileExt = (fileName.Split('.')[fileName.Split('.').Length - 1]);
            return File(fileBytes, "image/" + (fileName.Split('.')[fileName.Split('.').Length - 1]), fileName);
            //return new FileContentResult(fileBytes, "image/" + (fileName.Split('.')[fileName.Split('.').Length - 1]));
            
            //{
            //    File
            //    FileDownloadName = filePath
            //};
        }

        private string GetNameAndSetDeptFromAD(string emailID)
        {
            string fullName = null;
            string deptName = null;
            DirectoryEntry directoryEntry = new DirectoryEntry("LDAP://RootDSE");
            if (directoryEntry != null)
            {
                DirectoryEntry directoryEntry2 = null;
                try
                {
                    DirectoryEntry searchRoot = new DirectoryEntry("LDAP://" + directoryEntry.Properties["defaultNamingContext"].Value.ToString(), null, null, AuthenticationTypes.Secure);
                    string filter = string.Format("(&(ObjectClass={0})(mail={1}))", "top", emailID);
                    SearchResult searchResult = new DirectorySearcher(searchRoot)
                    {
                        Filter = filter
                    }.FindOne();
                    directoryEntry2 = searchResult.GetDirectoryEntry();
                    if (directoryEntry2.Properties["cn"] != null)
                    {
                        fullName = directoryEntry2.Properties["cn"].Value.ToString();
                    }
                }
                catch(Exception ex)
                {
                    fullName = "Error";
                }
                try
                {
                    if (directoryEntry2.Properties["distinguishedName"].Value != null)
                    {
                        if (directoryEntry2.Properties["distinguishedName"][0] != null)
                        {
                            if(!directoryEntry2.Properties["distinguishedName"][0].ToString().Split(',')[2].Split('=')[1].Contains("Authority"))
                            {
                                deptName = directoryEntry2.Properties["distinguishedName"][0].ToString().Split(',')[2].Split('=')[1];
                            }
                            else
                            {
                                deptName = directoryEntry2.Properties["distinguishedName"][0].ToString().Split(',')[1].Split('=')[1];
                            }
                            //int num = this.IndexOfNth(directoryEntry2.Properties["distinguishedName"][0].ToString().Split(',')[2].Split('=')[1], " ", 2);
                            //if (num != -1)
                            //{
                            //    deptName = directoryEntry2.Properties["distinguishedName"][0].ToString().Split(',')[2].Split('=')[1].Substring(0, num);
                            //}
                            //else
                            //{
                            //    num = this.IndexOfNth(directoryEntry2.Properties["distinguishedName"][0].ToString().Split(',')[1].Split('=')[1], " ", 2);
                            //    if (num != -1)
                            //    {
                            //        deptName = directoryEntry2.Properties["distinguishedName"][0].ToString().Split(',')[1].Split('=')[1].Substring(0, num);
                            //    }
                            //}
                            //if (deptName == null)
                            //{
                            //    deptName = "NA";
                            //    SelectItemFromDDL(deptName);
                            //    //SetDeptToOther();                          
                            //}
                            //else
                            //{
                                //List<SelectListItem> list = new List<SelectListItem>();
                                //list.Add(new SelectListItem
                                //{
                                //    Text = deptName,
                                //    Value = deptName
                                //});
                                //ViewData["Departments"] = list;
                                SelectItemFromDDL(deptName);
                                //SelectItemFromDDL("Engineering Services Department");
                            //}
                        }
                    }
                    else
                    {
                        //SetDeptToOther();
                        SelectItemFromDDL("Not Applicable");
                        //SelectItemFromDDL("Engineering Services Department");
                    }
                    
                }
                catch(Exception ex)
                {
                    ViewData["Departments"] = "Not Applicable";
                }
            }
            return fullName;
        }


        private void SetDeptToOther()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            list.Add(new SelectListItem
            {
                Text = "Other",
                Value = "Other"
            });
            ViewData["Departments"] = list; 
        }

        private DirectoryEntry GetUserInfoFromActiveDirectory(string emailID)
        {
            DirectoryEntry directoryEntry = new DirectoryEntry("LDAP://RootDSE");
            DirectoryEntry searchRoot = new DirectoryEntry("LDAP://" + directoryEntry.Properties["defaultNamingContext"].Value.ToString(), null, null, AuthenticationTypes.Secure);
            string filter = string.Format("(&(ObjectClass={0})(mail={1}))", "top", emailID);
            SearchResult searchResult = new DirectorySearcher(searchRoot)
            {
                Filter = filter
            }.FindOne();
            DirectoryEntry directoryEntry2 = searchResult.GetDirectoryEntry();
            return directoryEntry2;
        }

        public void GetDataFromActiveDirectory(EBDServiceRequests ebdservicerequests)
        {
            string deptName = null;
            string sectionName = null;
            DirectoryEntry directoryEntry = new DirectoryEntry("LDAP://RootDSE");
            if (directoryEntry != null)
            {
                try
                {
                    //DirectoryEntry searchRoot = new DirectoryEntry("LDAP://" + directoryEntry.Properties["defaultNamingContext"].Value.ToString(), null, null, AuthenticationTypes.Secure);
                    //string filter = string.Format("(&(ObjectClass={0})(mail={1}))", "top", ebdservicerequests.emailID);
                    //SearchResult searchResult = new DirectorySearcher(searchRoot)
                    //{
                    //    Filter = filter
                    //}.FindOne();
                    DirectoryEntry directoryEntry2 = GetUserInfoFromActiveDirectory(ebdservicerequests.emailID);
                    base.ModelState.Remove("empName");
                    base.ModelState.Remove("jobTitle");
                    base.ModelState.Remove("phoneNumber");
                    if (directoryEntry2.Properties["cn"] != null)
                    {
                        if (directoryEntry2.Properties["cn"][0] != null)
                        {                        
                            ebdservicerequests.empName = directoryEntry2.Properties["cn"][0].ToString().Trim();
                        }
                    }

                    if (directoryEntry2.Properties["title"].Value != null)
                    {
                        if (directoryEntry2.Properties["title"][0] != null)
                        {                             
                            ebdservicerequests.jobTitle = directoryEntry2.Properties["title"][0].ToString();
                        }
                    }

                    if (directoryEntry2.Properties["telephoneNumber"].Value != null)
                    {
                        if (directoryEntry2.Properties["telephoneNumber"][0] != null)
                        {                            
                            ebdservicerequests.phoneNumber = directoryEntry2.Properties["telephoneNumber"][0].ToString();
                        }
                    }

                    if (directoryEntry2.Properties["distinguishedName"].Value != null)
                    {
                        if (directoryEntry2.Properties["distinguishedName"][0] != null)
                        {
                            int num = this.IndexOfNth(directoryEntry2.Properties["distinguishedName"][0].ToString().Split(',')[2].Split('=')[1], " ", 2);
                            if (num != -1)
                            {
                                deptName = directoryEntry2.Properties["distinguishedName"][0].ToString().Split(',')[2].Split('=')[1].Substring(0, num);
                            }
                            else
                            {
                                num = this.IndexOfNth(directoryEntry2.Properties["distinguishedName"][0].ToString().Split(',')[1].Split('=')[1], " ", 2);
                                if (num != -1)
                                {
                                    deptName = directoryEntry2.Properties["distinguishedName"][0].ToString().Split(',')[1].Split('=')[1].Substring(0, num);
                                }
                            }
                            if (deptName == null)
                            {
                                deptName = "Not Applicable";
                                Session["DepartmentID"] = "1";//1->Not Applicable;
                            }
                            else
                            {
                                num = this.IndexOfNth(directoryEntry2.Properties["distinguishedName"][0].ToString().Split(',')[1].Split('=')[1], " ", 2);
                                if (num != -1)
                                {
                                    sectionName = directoryEntry2.Properties["distinguishedName"][0].ToString().Split(',')[1].Split('=')[1];
                                    if (sectionName.Contains("Department"))
                                    {
                                        sectionName = "Not Applicable";
                                        Session["SectionID"] = "8"; //"8"->"Not Applicable";                                         
                                    }
                                    else
                                    {
                                        if (sectionName.Equals("Project Budget Planning & Control Section"))
                                        {
                                            sectionName = "Payment Section";
                                        }
                                        else if (sectionName.Equals("Planning & Cost Control Section"))
                                        {
                                            sectionName = "Cost Control Section";
                                        }
                                    }
                                }

                            }
                        }
                    }
                    else
                    {
                        Session["DepartmentID"] = "1"; //1-> "Not Applicable";
                        Session["SectionID"] = "8"; //8->Not Applicable";
                    }
                     
                }
                catch (Exception)
                {
                    ViewData["ExcepMessage"] = "Invalid EmailId, Error Occurred while retrieving the data of the user. Try again, and if the problem persists see your system administrator";
                }
            }

            if (deptName != null && ViewData["ExcepMessage"] == null)
            {
                IQueryable<Department> queryDept = (from dept in db.Department
                                                    where dept.deptName.StartsWith(deptName)
                                                    select dept);
                if (queryDept.Count<Department>() != 0)
                {
                    //ViewBag.EmpDeptNameDisabled = true;                   
                    Session["DepartmentID"] = queryDept.Select(t => t.departmentID).AsEnumerable<short>().First<short>();
                        //(from c in this.db.Department
                        //                     where c.deptName.StartsWith(deptName) //c.deptName.Contains(deptName) || c.deptName.EndsWith(deptName)
                        //                     select c.departmentID).AsEnumerable<short>().First<short>();
                    //Session["DepartmentID"] = TempData["DepId"];
                }
                else
                {
                    Session["DepartmentID"] = "1"; //1->"Not Applicable";                     
                }
            }
            
                this.FillDepartments();
            
                this.FillSections();
                
                if (sectionName != null)
                {
                    IQueryable<Section> querySec = (from sec in db.Section
                                                    where sec.sectionName.StartsWith(sectionName)
                                                    select sec);
                    if (querySec.Count() != 0)
                    {
                        Session["SectionID"] = querySec.Select(t => t.sectionID).AsEnumerable<int>().First<int>();
                    }                    
                    else
                    {
                        Session["SectionID"] = "8"; //8-> "Not Applicable";
                    }
                }   
                else
                {
                    Session["SectionID"] = "8"; //8-> "Not Applicable";
                }

        }

        

        private void SendEmail(string reqEmailID,string tlEmailID, string jobNo, string srDescription)
        {
            SmtpClient smtpclient = new SmtpClient(ConfigurationManager.AppSettings["ipaddress"].ToString(), Convert.ToInt16(ConfigurationManager.AppSettings["port"].ToString()));
            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            MailAddress fromaddress = new MailAddress(ConfigurationManager.AppSettings["adminEmailID"].ToString());
            mail.From = fromaddress;
            mail.To.Add(reqEmailID);
            mail.CC.Add(tlEmailID);
            mail.Subject = ("eBook Service Request Job No. " + jobNo);
            mail.IsBodyHtml = true;


            mail.Body = " Dear EBook Admin, " +
                        "<br/> " +
                        "<br/> " +
                                "&nbsp; &nbsp; &nbsp; A Service Request has been created by user having EmailID " + reqEmailID +
                                " <br/> " +
                                " <br/> " +
                                "&nbsp; &nbsp; &nbsp; Job No.: " + jobNo +
                                " <br/> " +
                                " <br/> " +
                                "&nbsp; &nbsp; &nbsp; Service Request Description: " + srDescription +
                                " <br/> " +
                                " <br/> ";
             
            smtpclient.EnableSsl = true;             
            smtpclient.UseDefaultCredentials = false;

            try
            {
                smtpclient.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["userName"].ToString(), ConfigurationManager.AppSettings["password"].ToString());
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                try
                {
                    DelegateEmail myAction = new DelegateEmail(SendCompletedCallback);
                    myAction.BeginInvoke(smtpclient, mail, null, null);
                    //smtpclient.Send(mail);
                }
                catch (System.Exception ex)
                {
                    ViewData["ExcepMessage"] = "Error Occurred while sending an email "+ex.Message.Replace("'","");
                }
                
                
            }
            catch (System.Exception ex)
            {
                ViewData["ExcepMessage"] = "Error Occurred while sending an email " + ex.Message.Replace("'", "");
            }
        }

        private delegate void DelegateEmail(SmtpClient smtpclient, System.Net.Mail.MailMessage mail);

        private void SendCompletedCallback(SmtpClient smtpclient, System.Net.Mail.MailMessage mail) //private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e
        {
            try
            {
                smtpclient.Send(mail);
            }
            catch (System.Exception ex)
            {
                ViewData["ExcepMessage"] = "Error Occurred while sending an email";
            }
            //finally
            //{
            //    mail.Dispose();
            //    mail = null;
            //    // smtpclient = null;
            //}
        }

        public int IndexOfNth(string str, string value, int nth)
        {
            int num = str.IndexOf(value);
            for (int i = 1; i < nth; i++)
            {
                if (num == -1)
                {
                    return -1;
                }
                num = str.IndexOf(value, num + 1);
            }
            return num;
        }

        //private void SetDisbaledProperties(bool isDisbaled)
        //{
        //    ViewData["EmpNameDisabled"] = isDisbaled;
        //    ViewData["EmpDeptNameDisabled"] = isDisbaled;            
        //    ViewData["EmpSectNameDisabled"] = isDisbaled;                          
        //    //ViewBag.EmpJobTitleDisabled = isDisbaled;            
        //}         
    }
}
