﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;

namespace EBDServiceRequest
{
    /// <summary>
    /// Summary description for WebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService : System.Web.Services.WebService
    {

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string[] GetProjectTitleByPrjCode(string prjCode)
        {
            List<string> projCtrInfo = new List<string>();
            string strQuery = string.Empty;

            //List<SelectListItem> list = new List<SelectListItem>();
            //IQueryable<ServiceType> queryable = from svcType in this.db.ServiceType
            //                                    where svcType.serviceTypeID != 4
            //                                    select svcType;
            //foreach (ServiceType current in ((IEnumerable<ServiceType>)queryable))
            //{
            //    list.Add(new SelectListItem
            //    {
            //        Text = current.serviceTypeDescription,
            //        Value = current.serviceTypeID.ToString()
            //    });
            //}

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["TCMSConn"].ConnectionString;
                strQuery = "SELECT ctr.Contract_No,Replace(prj.project_newname_en,',','') as project_newname_en,prj.project_code FROM PROJECTS prj INNER JOIN CONTRACTORS ctr ON " +
                "prj.proj_id = ctr.proj_id WHERE prj.project_code like '%' + @SearchText + '%'";

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = strQuery;
                    cmd.Parameters.AddWithValue("@SearchText", prjCode);
                    cmd.Connection = conn;
                    conn.Open();
                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        while (sdr.Read())
                        {
                            projCtrInfo.Add(string.Format("{0}${1}${2}", sdr["Contract_No"].ToString(), sdr["project_newname_en"].ToString(), sdr["project_code"].ToString()));
                            //customers.Add(string.Format("{0}-{1}", sdr["Contract_No"], sdr["bidder_ID"]));
                        }
                    }
                    conn.Close();
                }
            }

            return projCtrInfo.ToArray();
        }
    }
}
